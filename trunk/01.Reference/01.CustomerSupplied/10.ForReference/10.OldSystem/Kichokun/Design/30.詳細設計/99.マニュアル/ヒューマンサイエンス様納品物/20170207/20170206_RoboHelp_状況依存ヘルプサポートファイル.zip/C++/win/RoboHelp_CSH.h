/***************************************************************************************** 
	Context-Sensitive-Help API for Multiscreen Help, HTML Help, WebHelp, WebHelp/FlashHelp Pro, FlashHelp, Adobe AIR

	Copyright � [2009] Adobe Systems Incorporated. All rights reserved. 

*****************************************************************************************

     Syntax:
     int RH_ShowHelp(HWND hParent, const char * a_pszHelpFile, unsigned int uCommand, DWORD dwData)

     hParent
          Handle to the parent window. Can be a window handle or 0.
		  If hParent == -1, uses IE to display the CSH Topic.
		  Otherwise the CSH topic will be displayed in a window which host an IE control. 
		  This is to avoid Local Machine Zone lockdown which was introduced by SP2 for Windows XP.
 
		  By default, when the IE control is hosted inside the application we comment out the toolbar. 
		  To enable the toolbar, look for BuildToolBar and uncomment that line. 
		  The toolbar has three buttons; back, forward and print.

     a_pszHelpFile
          WebHelp/FlashHelp:
               Path to help system start page ("http://www.myurl.com/help/help.htm" or "/help/help.htm")
               For custom windows (defined in Help project), add ">" followed by the window name ("/help/help.htm>mywin")

          WebHelp/FlashHelp Pro:
               Path to RoboHelp server ("http://myurl/robohelp/server")
               If automatic merging is turned off on RoboHelp Server, specify the project name in the URL (project=myproject)
               For custom windows (defined in Help project), specify the window name (wnd=mywindow)
			   If any area other then default(general) is to be accessed, specify area name (area=myarea)
			   Be default WebHelpPro projects are accessed, if FlashHelp Pro is to be accessed then specify type (type=flashhelp) in the URL
			   If relative URL of topic is to be accessed directly then specify specify tpc parameter (tpc=topicurl) 
			   
			   Example: http://myurl/robohelp/server?project=myproject&wnd=mywindow&ctxid=topicid&area=myarea

     uCommand
          Command to display help. One of the following:
               HH_HELP_CONTEXT     ' Displays the topic associated with the Map ID sent in dwData
										if 0, then default topic is displayed.
               The following display the default topic and the Search, Index, or TOC pane.
               Note: The pane displayed in WebHelp Pro will always be the window's default pane.
                    HH_DISPLAY_SEARCH
                    HH_DISPLAY_INDEX
                    HH_DISPLAY_TOC

     dwData
          Map ID associated with the topic to open (if using HH_HELP_CONTEXT), otherwise 0

     Examples:
		  RH_ShowHelp(GetSafeHwnd(), "http://www.myurl.com/help/help.htm", HH_HELP_CONTEXT, (DWORD)10);
		  RH_ShowHelp(GetSafeHwnd(), "C:\Program Files\MyApp\help\help.htm", HH_HELP_CONTEXT, (DWORD)100);

*****************************************************************************************
     To use airplane help, you will need to associate offline help before any help calls are made.
     Once associated, help calls will use the primary help when an internet connection is present, otherwise they will fall back on the local help.

     Syntax:
     void RH_AssociateOfflineHelp(const char * a_pszPrimaryHelpSource, const char * a_pszBackupHelpSource)

     Examples:
          RH_AssociateOfflineHelp("http://www.myurl.com/robohelp/server?project=MyAppHelp", "C:\Program Files\MyApp\help\help.htm");  // Associates WebHelp/FlashHelp Pro and local WebHelp/FlashHelp
          RH_AssociateOfflineHelp("http://www.myurl.com/help/help.htm>MyWebHelpWindow", "C:\Program Files\MyApp\help.chm>MyHTMLHelpWindow"); // Associates remote WebHelp/FlashHelp and local HTML Help (specifying windows)

******************************************************************************************
 The Helper function for Multiscreen Context Sensitive Help using Map Number
------------------------------------------------------------------------------------------
		Syntax:
		int RH_ShowMultiscreenHelpWithMapId(HWND hParent, const _TCHAR *pszHelpURL,	const _TCHAR *pszWnd, DWORD dwMapNo);

		Parameters:
			hParent
				Handle to the parent window

			pszHelpURL
					Path to help system start page ('http://www.myurl.com/help/index.htm' or '/help/index.htm')

			pszWnd
					Name of custom window in which the help is to be shown.
					Allowed values:
								Window Name String	to specify a window	: e.g. "MultiScreenWindow"
								NULL value to specify no window

			dwMapNo
          		Map number associated with the topic to open. 
					Allowed values:
								Map number for a specific topic			: e.g. 10
								Zero value for opening the default topic

		Examples:
			RH_ShowMultiscreenHelpWithMapNo("help/index.htm", NULL, 10)">; //Help for topic with Map number 10
			RH_ShowMultiscreenHelpWithMapNo("help/index.htm", "MultiScreenWindow", 10); //Help in Custom Window Name MultiScreenWindow
******************************************************************************************
 The Helper function for Multiscreen Context Sensitive Help using Map Id
------------------------------------------------------------------------------------------
		Syntax:
		int RH_ShowMultiscreenHelpWithMapId(HWND hParent, const _TCHAR *pszHelpURL,	const _TCHAR *pszWnd, const _TCHAR *pszMapId);

		Parameters:
			hParent
				Handle to the parent window

			pszHelpURL
					Path to help system start page ('http://www.myurl.com/help/index.htm' or '/help/index.htm')

			pszWnd
					Name of custom window in which the help is to be shown.
					Allowed values:
								Window Name String	to specify a window	: e.g. "MultiScreenWindow"
								NULL value to specify no window

			pszMapId
					Map ID associated with the topic to open.
					Allowed values
								Map ID for a specific topic					: e.g. "HelpTopic"
								NULL value for opening the default topic

		Examples:
			RH_ShowMultiscreenHelpWithMapId("help/index.htm", NULL, "HelpTopic")">; //Help for topic with Map Id "HelpTopic"
			RH_ShowMultiscreenHelpWithMapId("help/index.htm", "MultiScreenWindow", "HelpTopic"); //Help in Custom Window Name MultiScreenWindow
******************************************************************************************
 The Helper function for passing key stroke messages to Multiscreen and WebHelp window for Index and Glossary filtering
------------------------------------------------------------------------------------------

		Syntax:
		int RH_ProcessKeyStrokes(MSG* a_pMsg);

		Parameter:
			a_pMsg
				Key Up and Key Down messages to be handled by the Help Window. 
				Any message recevived in the message loop of parent window can be passed. It will be filtered by the Help window.

		Return Value:
			The return value is 0 if the message is handled by the Help window and non-zero if not handled.

		Note:
			This function must be placed in the message loop(e.g. PreTranslateMessage()) of the parent window(that is calling Help API)
			for Index & Glossary filtering to work.

******************************************************************************************/

#ifndef ROBOHELP_CSH_H
#define ROBOHELP_CSH_H

#ifdef __cplusplus
extern "C"
{
#endif

//   RH_AssociateOfflineHelp
//		[in] a_pszPrimaryHelpSource		- primary server-based help system
//		[in] a_pszBackupHelpSource		- backup help system
void RH_AssociateOfflineHelp(const _TCHAR * a_pszPrimaryHelpSource, 
							 const _TCHAR * a_pszBackupHelpSource);

//   RH_ShowHelp
//		[in] hwndParent		- window handle to the parent window.
//		[in] a_pszHelpFile	- help file name or url to server-based help system
//		[in] uCommand		- pre-defined command used based on the help file
//		[in] dwData			- extra data based on the uCommand parameter specified
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_ShowHelp(HWND hParent,
				const _TCHAR * a_pszHelpFile,
				unsigned int uCommand,
				DWORD dwData);

// RH_OpenHelpTopic
//              [in] a_pszHelpMainPage - Help file name or url to Webhelp/FlashHelp Main page
//              [in] a_pszTopicRelPath - Relative path of the Topic corresponding to the Main Page
int RH_OpenHelpTopic(const _TCHAR * a_pszHelpMainPage, 
                     const _TCHAR * a_pszTopicRelPath);

//This API works for only Webhelp output with Multiple Table of contents.
//RH_ShowHelpForContext
//		[in] hwndParent		- window handle to the parent window.
//		[in] a_pszHelpFile	- help file name or url to server-based help system
//		[in] a_pszContext   - Context or role name
//		[in] uCommand		- pre-defined command used based on the help file
//		[in] dwData			- extra data based on the uCommand parameter specified
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_ShowHelpForContext(HWND hParent, 
						 const _TCHAR * a_pszHelpFile, 
						 const _TCHAR *a_pszContext,
						 unsigned int uCommand, 
						 DWORD dwData
						);

//   RH_ShowMultiscreenHelpWithMapNo
//		[in] hParent		- window handle to the parent window.
//		[in] pszHelpURL		- help file name or url to help system
//		[in] pszWnd			- name of the custom window
//		[in] dwMapNo		- map number associated with the topic to be shown
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_ShowMultiscreenHelpWithMapNo(HWND hParent, 
							const _TCHAR *pszHelpURL,
							const _TCHAR *pszWnd,
							DWORD dwMapNo=0
							);

//   RH_ShowMultiscreenHelpWithMapId
//		[in] hParent		- window handle to the parent window.
//		[in] pszHelpURL		- help file name or url to help system
//		[in] pszWnd			- name of the custom window
//		[in] pszMapId		- map id associated with the topic to be shown
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_ShowMultiscreenHelpWithMapId(HWND hParent, 
							const _TCHAR *pszHelpURL,
							const _TCHAR *pszWnd,
							const _TCHAR *pszMapId=NULL
							);

//   RH_AIR_ShowHelp
//		[in] a_pszViewerPath	- Path to the installation directory of AIR Help Application.
//		[in] a_pszHelpId		- [optional] id of help content(.rha) to be viewed in Viewer. It is specified in .helpcfg file.
//		[in] a_pszWindowName	- [optional] customized named output window
//		[in] ulMapNum			- Content Sensitive Map Number. 
//		[in] a_pszMapId			- [optional] String representation of ulMapNum. If specified this takes priority and ulMapNum is ignored.
//		[in] a_pszTopicURL		- [optional] URL of topic to be shown. If specified this takes priority over ulMapNum and a_pszMapId.
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_AIR_ShowHelp(const _TCHAR * a_pszViewerPath,
				const _TCHAR * a_pszHelpId,
				const _TCHAR * a_pszWindowName,
				unsigned long ulMapNum,
				const _TCHAR * a_pszMapId,
				const _TCHAR * a_pszTopicURL);

//   RH_Show_BrowserBasedHelp
//		[in] hwndParent			- window handle to the parent window.
//		[in] pszHelpURL			- help file name or url to server-based help system
//		[in] pszContext			- Context or role name
//		[in] a_pszWindowName	- [optional] customized named output window
//		[in] uCommand			- pre-defined command used based on the help file
//		[in] dwData				- extra data based on the uCommand parameter specified
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_Show_BrowserBasedHelp(HWND hParent, 
							 const _TCHAR * pszHelpURL,
							 const _TCHAR *pszContext,
							 const _TCHAR *pszWnd,
							 unsigned int uCommand,
							 DWORD dwData
							 );

//   RH_AssociateOfflineHelp
//		[in] a_pszPrimaryHelpSource		- primary server-based help system
//		[in] a_pszBackupHelpSource		- backup help system

void RH_AssociateOfflineHelp(const _TCHAR * a_pszPrimaryHelpSource, 
							 const _TCHAR * a_pszBackupHelpSource);

//   RH_AssociateQuickStart
//		[in] a_pszPrimaryHelpSource		- primary server-based help system
//		[in] a_pszQuickStart			- Quick start files
//		[in] bUpdate					- determines whether to update out of date files

void RH_AssociateQuickStart(const _TCHAR * a_pszPrimaryHelpSource,
							const _TCHAR * a_pszQuickStart,
							int nUpdate);

//	RH_ProcessKeyStrokes
//		[in] a_pMsg		- Key Up and Key Down messages to be handled by the Help Window
//		The return value is 0 if the message is handled by the Help window and non-zero if not handled.
int RH_ProcessKeyStrokes(MSG* a_pMsg);

//	 RH_RegisterTopicBrowser
//		[in] a_pUnknown					- instance of IE control. will be used to show CSH content of Webhelp or FlashHelp.

int	 RH_RegisterTopicBrowser(IUnknown *a_pUnknown);

//	 RH_UnregisterTopicBrowser			- unregister topic browser. After this CSH content will be displayed in a stand alone IE control or IE browser not controled by the caller.
//		If RH_RegisterTopicBrowser is used. Please use this function before destory the topic browser or application ends.
int	 RH_UnregisterTopicBrowser();

#ifdef __cplusplus
}
#endif


#endif // ROBOHELP_CSH_H