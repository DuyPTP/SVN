' Copyright� 2009 Adobe Systems Incorporated. All rights reserved.
' RoboHelp_CSH.vb
' The Unified Helper function for Context Sensitive Help(WebHelp and WebHelp Enterprise)
 
'
'     Syntax:
'     Public Function RH_ShowHelp(hParent As Long, a_pszHelpFile As String, uCommand As Long, dwData As Long) As Boolean
'
'     [in]hParent
'          Handle to the parent window. This is currently reserved for future versions of the API.
'          Can be a window handle or 0.
'
'     [in]a_pszHelpFile
'          WebHelp:
'               Path to help system start page ("http://www.myurl.com/help/help.htm" or "/help/help.htm")
'               For custom windows (defined in Help project), add ">" followed by the window name ("/help/help.htm>mywin")
'
'          WebHelp Enterprise:
'               Path to RoboEngine server ("http://RoboEngine/roboapi.asp")
'               If automatic merging is turned off in RoboEngine Configuration Manager, specify the project name in the URL ("http://RoboEngine/roboapi.asp?project=myproject")
'               For custom windows (defined in Help project), add ">" followed by the window name ("http://RoboEngine/roboapi.asp>mywindow")
'
'     [in]uCommand
'          Command to display help. One of the following:
'                    HH_HELP_CONTEXT     ' Displays the topic associated with the Map ID sent in dwData
'                                          if 0, then default topic is displayed.
'               The following display the default topic and the Search, Index, or TOC pane.
'               Note: The pane displayed in WebHelp Enterprise will always be the window's default pane.
'                    HH_DISPLAY_SEARCH
'                    HH_DISPLAY_INDEX
'                    HH_DISPLAY_TOC
'
'     [in]dwData
'          Map ID associated with the topic to open (if using HH_HELP_CONTEXT), otherwise 0
'
'     The return value is	true  for a successful result and false if an error occurs.
'     Examples:
'          ' First, create a RoboHelp_CSH object (this should be a global object in your application)
'          Public cshObject as new RoboHelp_CSH
'
'          cshObject.RH_ShowHelp Me.HWND, "http://www.myurl.com/help/help.htm", cshObject.HH_HELP_CONTEXT, 10  'Show map id 10 on remote WebHelp
'          cshObject.RH_ShowHelp Me.HWND, "C:\Program Files\MyApp\help\help.htm", cshObject.HH_HELP_CONTEXT, 100  'Show map id 100 on local WebHelp
'
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'     To use airplane help, you will need to associate offline help before any help calls are made.
'     Once associated, help calls will use the primary help when an internet connection is present, otherwise they will fall back on the local help.
'
'     Syntax:
'     Public Function RH_AssociateOfflineHelp(a_pszPrimaryHelpSource As String, a_pszBackupHelpSource As String) As Boolean
'
'     Examples:
'          ' First, create a RoboHelp_CSH object (this should be a global object in your application)
'          Public cshObject as new RoboHelp_CSH
'
'          cshObject.RH_AssociateOfflineHelp "http://RoboEngine/roboapi.asp?project=MyAppHelp", "C:\Program  Files\MyApp\help\help.htm"  ' Associates WebHelp Enterprise and local WebHelp
'          cshObject.RH_AssociateOfflineHelp "http://www.myurl.com/help/help.htm>MyWebHelpWindow", "C:\Program Files\MyApp\help.chm>MyHTMLHelpWindow"  ' Associates remote WebHelp and local HTML Help (specifying windows)

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

'
'	 RH_AIR_ShowHelp
'		[in] a_pszViewerPath	- Path to the installation directory of AIR Help Application.
'		[in] a_pszHelpId		- [optional] id of help content to be viewed in Viewer. It is specified in .helpcfg file.
'		[in] a_pszWindowName	- [optional] customized named output window
'		[in] ulMapNum			- Content Sensitive Map Number. 
'		[in] a_pszMapId			- [optional] String representation of ulMapNum. If specified this takes priority and ulMapNum is ignored.
'		[in] a_pszTopicURL		- [optional] URL of topic to be shown. If specified this takes priority over ulMapNum and a_pszMapId.
'		The return value is	true  for a successful result and false if an error occurs.


Imports System
Imports System.Runtime.InteropServices



Public Class RoboHelp_CSH
    Inherits Form

    Const MAX_PATH = 256
    Const szTargetID = "__WebHelpCshStub"
    Dim stBrowser As New WebBrowser

    Private Declare Function WinHelp Lib _
        "user32" Alias "WinHelpA" _
           (ByVal hWndMain As Long, _
            ByVal lpszHelp As String, _
            ByVal uCommand As Long, _
            ByVal dwData As Long) As Long

    Private Declare Function HtmlHelp Lib _
        "hhctrl.ocx" Alias "HtmlHelpA" _
           (ByVal hWndMain As Long, _
            ByVal lpszHelp As String, _
            ByVal uCommand As Long, _
            ByVal dwData As Long) As Long

    Private Declare Function InternetGetConnectedState Lib _
        "wininet" ( _
            ByRef dwFlags As Long, _
            ByVal dwReserved As Long) As Boolean

    Private Declare Function InternetCheckConnection Lib _
        "wininet" Alias "InternetCheckConnectionA" _
           (ByVal lpszUrl As String, _
            ByVal dwFlags As Long, _
            ByVal dwReserved As Long) As Boolean

    'Lib _ "shell32.dll" Alias "ShellExecuteW" _
    <DllImport("shell32.dll", CharSet:=CharSet.Unicode)> _
    Public Shared Function ShellExecuteW _
           (ByVal hWnd As Long, _
            ByVal lpOperation As String, _
            ByVal lpFile As String, _
            ByVal lpParameters As String, _
            ByVal lpDirectory As String, _
            ByVal nShowCmd As Long) As Long
    End Function

    Private Declare Function SetWindowPos Lib _
        "user32.dll" _
            (ByVal hWnd As Long, _
             ByVal hWndInsertAfter As Long, _
             ByVal x As Integer, _
             ByVal Y As Integer, _
             ByVal CX As Integer, _
             ByVal CY As Integer, _
             ByVal uFlags As Integer) As Boolean

    Private Function LaunchProcess(ByVal strAppPath As String, ByVal strCommandline As String) As Boolean
        Process.Start(strAppPath, strCommandline)
        Return True
    End Function

    Private PrimaryHelpSet(20) As String
    Private BackupHelpSet(20) As String
    Private nBackupCount As Integer

    Private UnavailableHelpSet(20) As String
    Private nUnabailableHelpSetCount As Integer

    ' Please add a reference to Microsoft Internet Controls from menu Project|References first.
    Public ReadOnly Property HH_DISPLAY_TOPIC() As Integer
        Get
            Return &H0
        End Get
    End Property

    Public ReadOnly Property HH_DISPLAY_TOC() As Integer
        Get
            Return &H1
        End Get
    End Property
    Public ReadOnly Property HH_DISPLAY_INDEX() As Integer
        Get
            Return &H2
        End Get
    End Property
    Public ReadOnly Property HH_DISPLAY_SEARCH() As Integer
        Get
            Return &H3
        End Get
    End Property
    Public ReadOnly Property HH_HELP_CONTEXT() As Integer
        Get
            Return &HF
        End Get
    End Property
    Public ReadOnly Property HELP_CONTEXT() As Integer
        Get
            Return &H1
        End Get
    End Property
    Public ReadOnly Property HELP_CONTENTS() As Integer
        Get
            Return &H3
        End Get
    End Property

    Public Function RH_AssociateOfflineHelp(ByVal a_pszPrimaryHelpSource As String, ByVal a_pszBackupHelpSource As String) As Boolean
        If (nBackupCount <= UBound(PrimaryHelpSet)) Then
            PrimaryHelpSet(nBackupCount) = a_pszPrimaryHelpSource
            BackupHelpSet(nBackupCount) = a_pszBackupHelpSource
            nBackupCount = nBackupCount + 1
            RH_AssociateOfflineHelp = True
        Else
            RH_AssociateOfflineHelp = False
        End If
    End Function
    Public Function RH_ShowHelp(ByVal hParent As Long, ByVal a_pszHelpFile As String, ByVal uCommand As Long, ByVal dwData As Long) As Boolean
        Dim bHasBackup As Boolean
        Dim tPrimary As String
        Dim tbackup As String
        Dim pszHelp As String
        Dim pWnd As String
        Dim i As Integer
        Dim nLen As Integer
        Dim nPos As Integer
        Dim uNewCommand As Integer
        Dim bHelpAvailable As Boolean

        tbackup = ""
        tPrimary = a_pszHelpFile
        For i = 0 To nBackupCount - 1
            If (PrimaryHelpSet(i) = tPrimary) Then
                tbackup = BackupHelpSet(i)
                bHasBackup = True
                Exit For
            End If
        Next

        If (Not bHasBackup) Then
            ' if primary has window associated, then try strip out the window and find again.
            nLen = Len(a_pszHelpFile)
            pszHelp = New String(a_pszHelpFile)

            nPos = InStr(1, pszHelp, ">", 0)
            If (nPos <> 0) Then
                pszHelp = a_pszHelpFile.Substring(0, nPos - 1)
                pWnd = a_pszHelpFile.Substring(nPos)
                For i = 0 To nBackupCount - 1
                    If (PrimaryHelpSet(i) = pszHelp) Then
                        tbackup = BackupHelpSet(i)
                        bHasBackup = True
                        Exit For
                    End If
                Next
                If (bHasBackup) Then
                    nPos = InStr(1, tbackup, ">", 0)
                    If (nPos = 0) Then
                        tbackup = tbackup & ">" & pWnd
                    End If
                End If
            End If
        End If

        bHelpAvailable = True
        For i = 0 To nUnabailableHelpSetCount - 1
            If (UnavailableHelpSet(i) = tPrimary) Then
                bHelpAvailable = False
                Exit For
            End If
        Next

        ' attempt to show the help
        If (bHelpAvailable) Then
            If (Not ShowHelp(hParent, a_pszHelpFile, uCommand, dwData)) Then
                UnavailableHelpSet(nUnabailableHelpSetCount) = tPrimary
                nUnabailableHelpSetCount = nUnabailableHelpSetCount + 1
            Else
                RH_ShowHelp = True
                Exit Function
            End If
        End If

        ' try the backup help system, if there is one
        If (bHasBackup) Then
            ' make sure we're using the appropriate command for the backup
            uNewCommand = GetCommandForHelpSource(tbackup, dwData)
            If (uNewCommand <> 0) Then
                uCommand = uNewCommand
            End If
            RH_ShowHelp = ShowHelp(hParent, tbackup, uCommand, dwData)
            Exit Function
        Else
            RH_ShowHelp = False
            Exit Function
        End If

    End Function

    Private Function ShowHelp(ByVal hParent As Long, ByVal pszHelpSource As String, ByVal uCommand As Long, ByVal dwData As Long) As Boolean
        ShowHelp = False

        If (IsWinHelp(pszHelpSource)) Then
            If (WinHelp(hParent, pszHelpSource, uCommand, dwData) = 1) Then
                ShowHelp = True
            End If
            Exit Function
        End If

        If (IsHtmlHelp(pszHelpSource)) Then
            If (HtmlHelp(hParent, pszHelpSource, uCommand, dwData) > 0) Then
                ShowHelp = True
            End If
            Exit Function
        End If

        If (IsWebAddress(pszHelpSource)) Then
            Dim dwFlags As Long
            If (InternetGetConnectedState(dwFlags, 0)) Then
                If ((1 And dwFlags) = 0) Then
                    'check for internet connection... if none Exit Function false
                    If (InternetCheckConnection(pszHelpSource, 1, 0)) Then
                        ShowHelp = WH_ShowHelp(hParent, pszHelpSource, uCommand, dwData)
                    End If
                End If
            End If
        Else
            ShowHelp = WH_ShowHelp(hParent, pszHelpSource, uCommand, dwData)
        End If

    End Function
    Private Function WH_ShowHelp(ByVal hParent As Long, ByVal pszHelpSource As String, ByVal uCommand As Long, ByVal dwData As Long) As Boolean
        Dim pszHelp As String
        Dim pWnd As String
        Dim nLen As Integer
        Dim nPos As Integer

        pWnd = ""
        WH_ShowHelp = False
        If (Len(pszHelpSource) > 0) Then
            nLen = Len(pszHelpSource)
            If (nLen <> 0) Then
                pszHelp = New String(pszHelpSource)

                nPos = InStr(1, pszHelp, ">", 0)
                If (nPos <> 0) Then
                    pszHelp = pszHelp.Substring(0, nPos - 1)
                    pWnd = pszHelpSource.Substring(nPos)
                End If

                If (IsServerBased(pszHelp)) Then
                    WH_ShowHelp = WH_ShowWebHelp_Server(hParent, pszHelp, pWnd, uCommand, dwData)
                Else
                    WH_ShowHelp = WH_ShowWebHelp(hParent, pszHelp, pWnd, uCommand, dwData)
                End If
            End If
        End If
    End Function

    Private Function IsServerBased(ByVal a_pszUrlToHelpSet As String) As Boolean
        Dim nPos As Integer

        nPos = InStrRev(a_pszUrlToHelpSet, ".")
        If (Not IsNull(nPos) And nPos <> 0 And Len(a_pszUrlToHelpSet) - nPos >= 3) Then
            If (StrComp(Mid(a_pszUrlToHelpSet, nPos, 4), ".htm", 1) = 0) Then
                IsServerBased = False
                Exit Function
            End If
        End If
        IsServerBased = True
    End Function

    Private Function WH_ShowWebHelp_Server(ByVal hParent As Long, ByVal pszHelpURL As String, ByVal pszWnd As String, ByVal uCommand As Long, ByVal dwData As Long) As Boolean
        Dim bCmd As Boolean
        Dim nPos As Integer
        Dim szParam As String
        Dim nWndLength As Integer
        Dim pszURL As String

        WH_ShowWebHelp_Server = False
        bCmd = False
        szParam = ""
        Select Case (uCommand)
            Case HH_HELP_CONTEXT
                nPos = InStr(1, pszHelpURL, "?")
                If (nPos <> 0) Then
                    szParam = "&ctxid=" & dwData
                Else
                    szParam = "?ctxid=" & dwData
                End If
                bCmd = True
            Case HH_DISPLAY_INDEX, HH_DISPLAY_SEARCH, HH_DISPLAY_TOC, HH_DISPLAY_TOPIC
                nPos = InStr(1, pszHelpURL, "?")
                If (nPos <> 0) Then
                    szParam = "&ctxid=0"
                Else
                    szParam = "?ctxid=0"
                End If
                bCmd = True
        End Select

        If (bCmd) Then
            szParam = Trim(szParam)
            nWndLength = 0
            If (Len(pszWnd) > 0) Then
                nWndLength = Len(pszWnd) + 1
            End If

            pszURL = pszHelpURL + szParam
            If (Len(pszWnd) > 0) Then
                pszURL = pszURL + ">" + pszWnd
            End If
            WH_ShowWebHelp_Server = ShowWebHelp(hParent, pszURL)
        End If
    End Function
    Private Function WH_ShowWebHelp(ByVal hParent As Long, ByVal pszHelpURL As String, ByVal pszWnd As String, ByVal uCommand As Long, ByVal dwData As Long) As Boolean
        Dim pszURL As String
        Dim szParam As String
        Dim nWndLength As Integer

        WH_ShowWebHelp = False
        szParam = ""
        Select Case (uCommand)
            Case HH_DISPLAY_TOPIC
                szParam = "#<id=0"
            Case HH_HELP_CONTEXT
                szParam = "#<id=" & dwData
            Case HH_DISPLAY_INDEX
                szParam = "#<cmd=idx"
            Case HH_DISPLAY_SEARCH
                szParam = "#<cmd=fts"
            Case HH_DISPLAY_TOC
                szParam = "#<cmd=toc"
        End Select

        szParam = Trim(szParam)
        If (Len(szParam) > 0) Then
            nWndLength = 0
            If (Not IsNull(pszWnd) And Len(pszWnd) > 0) Then
                nWndLength = Len(pszWnd) + 6
            End If

            pszURL = pszHelpURL + szParam
            If (Not IsNull(pszWnd) And Len(pszWnd) > 0) Then
                pszURL = pszURL + ">>wnd=" + pszWnd
            End If
            WH_ShowWebHelp = ShowWebHelp(hParent, pszURL)
        End If
    End Function

    Private Function ShowWebHelp(ByVal hParent As Long, ByVal pszURL As String) As Boolean
        ShowWebHelp = ShowHelpTopic_Win32_IE(pszURL)
    End Function

    Private Function ShowHelpTopic_Win32_IE(ByVal a_pszUrl As String) As Boolean
        Dim szParam As String
        Dim bServerBased As Boolean
        Dim nPos As Integer

        bServerBased = False
        If (Len(a_pszUrl) > 0) Then
            Dim pszURL As String
            If (IsServerBased(a_pszUrl)) Then
                bServerBased = True
                szParam = New String(" ", 0)
                nPos = InStr(1, a_pszUrl, "?")
                If (nPos <> 0) Then
                    szParam = "&cmd=newwnd&rtype=iefrm"
                Else
                    szParam = "?cmd=newwnd&rtype=iefrm"
                End If
                szParam = Trim(szParam)

                pszURL = New String("")
                pszURL = a_pszUrl + szParam
            Else
                pszURL = a_pszUrl
            End If

            If (Not bServerBased) Then
                pszURL = PrepareTempHtmlFile(pszURL)
            End If
            stBrowser.Navigate(pszURL)
            ShowHelpTopic_Win32_IE = True
        Else
            ShowHelpTopic_Win32_IE = False
        End If
    End Function

    Private Function PrepareTempHtmlFile(ByVal a_pszUrl As String) As String
        Dim szFile As String
        Dim szTempFileFormatPart1 As String
        Dim szTempFileFormatPart2 As String
        Dim szTotalUrl As String

        szFile = GetTempFile(a_pszUrl)

        szTempFileFormatPart1 = "<html>" & vbCrLf & "<script language=" & Chr(&H22) & _
            "Javascript" & Chr(&H22) & ">" & vbCrLf & "<!--" & vbCrLf & "document.location=" & Chr(&H22)

        szTempFileFormatPart2 = Chr(&H22) & ";" & vbCrLf & "//-->" & vbCrLf & "</script>" & vbCrLf & "</html>"

        If (InStr(1, a_pszUrl, "://") = 0) Then
            a_pszUrl = Replace(a_pszUrl, "\", "/")
            a_pszUrl = "file://" + a_pszUrl
        End If

        szTotalUrl = a_pszUrl

        Dim fso, txtfile
        fso = CreateObject("Scripting.FileSystemObject")
        txtfile = fso.CreateTextFile(szFile, True)
        txtfile.Write(szTempFileFormatPart1 & szTotalUrl & szTempFileFormatPart2)
        txtfile.Close()
        fso = Nothing

        PrepareTempHtmlFile = szFile
    End Function
    Private Function GetTempFile(ByVal a_pszUrl As String) As String
        Dim szFile As String
        Dim szTempPath As String

        szTempPath = My.Computer.FileSystem.GetTempFileName()


        szTempPath = Trim(szTempPath)
        szFile = szTempPath & "robohelp_csh.htm"
        GetTempFile = szFile
    End Function

    Private Function GetCommandForHelpSource(ByVal pszHelpSource As String, ByVal dwData As Long) As Integer
        If (IsWinHelp(pszHelpSource)) Then
            GetCommandForHelpSource = HELP_CONTEXT
            Exit Function
        End If

        If (IsHtmlHelp(pszHelpSource)) Then
            If (dwData > 0) Then
                GetCommandForHelpSource = HH_HELP_CONTEXT
                Exit Function
            End If
            GetCommandForHelpSource = HH_DISPLAY_TOPIC
            Exit Function
        End If

        If (dwData > 0) Then
            GetCommandForHelpSource = HH_HELP_CONTEXT
            Exit Function
        End If
        GetCommandForHelpSource = HH_DISPLAY_TOPIC
    End Function

    Private Function IsHtmlHelp(ByVal pszHelpSource As String) As Boolean
        Dim Mypos As Integer

        If (Len(pszHelpSource) > 0) Then
            Mypos = InStrRev(pszHelpSource, ".")
            If (Mypos <> 0 And Len(pszHelpSource) - Mypos >= 3) Then
                If (StrComp(Mid(pszHelpSource, Mypos, 4), ".chm", 1) = 0) Then
                    IsHtmlHelp = True
                    Exit Function
                End If
            End If
        End If
        IsHtmlHelp = False
    End Function

    Private Function IsWinHelp(ByVal pszHelpSource As String) As Boolean
        Dim Mypos As Integer

        If (Len(pszHelpSource) > 0) Then
            Mypos = InStrRev(pszHelpSource, ".")
            If (Mypos <> 0 And Len(pszHelpSource) - Mypos >= 3) Then
                If (StrComp(Mid(pszHelpSource, Mypos, 4), ".hlp", 1) = 0) Then
                    IsWinHelp = True
                    Exit Function
                End If
            End If
        End If
        IsWinHelp = False
    End Function

    Private Function IsWebAddress(ByVal pszHelpSource As String) As Boolean
        If (Len(pszHelpSource) > 7) Then
            If (StrComp(pszHelpSource.Substring(0, 7), "http://", 1) = 0) Then
                IsWebAddress = True
                Exit Function
            End If
        End If
        IsWebAddress = False
    End Function

    Private Function IsNull(ByRef obj As Object) As Boolean
        Return (obj Is Nothing)
    End Function

    Private Function AddStringParamToAIRCommandParams(ByRef cmdParam As String, ByRef paramName As String, ByRef paramVal As String) As Boolean
        If paramVal <> vbNullString And paramVal.Length > 0 Then
            cmdParam += " " + paramName + " " + Chr(34) + paramVal + Chr(34)
            Return True
        End If
        Return False
    End Function

    Public Function RH_AIR_ShowHelp(ByVal a_pszViewerPath As String, _
    ByVal a_pszHelpId As String, _
    ByVal a_pszWindowName As String, _
    ByVal ulMapNum As Long, _
    ByVal a_pszMapId As String, _
    ByVal a_pszTopicURL As String) As Boolean

        Dim cmdParam As String
        Dim bRetVal As Boolean
        bRetVal = False
        Dim fInfo As System.IO.FileInfo
        fInfo = My.Computer.FileSystem.GetFileInfo(a_pszViewerPath)

        If fInfo.Exists Then
            cmdParam = New String("-csh ")
            AddStringParamToAIRCommandParams(cmdParam, "helpid", a_pszHelpId)
            AddStringParamToAIRCommandParams(cmdParam, "window", a_pszWindowName)
            If Not AddStringParamToAIRCommandParams(cmdParam, "topicurl", a_pszTopicURL) Then
                If Not AddStringParamToAIRCommandParams(cmdParam, "mapid", a_pszMapId) Then
                    cmdParam += Str(ulMapNum)
                End If
            End If

            bRetVal = LaunchProcess(a_pszViewerPath, cmdParam)
        End If

        Return bRetVal
    End Function


End Class
