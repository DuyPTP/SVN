/***************************************************************************************** 
Context-Sensitive-Help API for HTML Help, WebHelp, WebHelp/FlashHelp Pro, FlashHelp, Adobe AIR

Copyright � [2009] Adobe Systems Incorporated. All rights reserved.
  
  IF YOU ARE USING VISUAL C++, PLEASE READ: 

  When adding this source code to your project, you must link to wininet.lib, urlmon.lib, psapi.lib and hhctrl.lib
  to avoid compiler linkage errors. Also, you must choose NOT to use precompiled headers
  for the "RoboHelp_CSH.cpp" file in your project settings. Otherwise, you will get EOF
  compiler errors.
  
*******************************************************************************************/
#pragma warning (disable : 4100 4710 4512 4786 4100 4663 4018 4702 4311 4312)
#pragma warning (push, 3)

#include <process.h>
#include <stdlib.h>
#include <stdio.h>

#ifdef _WIN32				//Win32 platform
#ifndef _ATL_DLL			// using ATL's window to host IWebbrowser.
#define _ATL_DLL
#endif
#include <atlbase.h>
CComModule _Module;
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <MSHTML.H>			// IE Interfaces.
#include <Exdisp.h>
#include <Exdispid.h>
#include <atlwin.h>
#include <psapi.h>
#else						//non-Win32 platform, probably Unix. here we include a header file for unix.
#define	 _TCHAR		char
#define  _tcslen	strlen
#define  _tcscpy	strcpy
#define  _tcsstr	strstr
#define  _tcscat	strcat
#define  _stprintf	sprintf
#define  _tcsrchr	strrchr
#define  _tcsnicmp	strnicmp
#include <unistd.h>
#endif

#include <map>
#include <string>
#include <set>
#include <tchar.h>
#include "wininet.h"
#include "htmlhelp.h"		// Microsoft HTML Help header file. You can find this under RoboHTML installation folder.
#include "RoboHelp_Csh.h"

static HWND g_hRoboHelp = NULL;

/***************************************************************************************** 
	FH Update and Window Constants
*****************************************************************************************/
#define FH_QUICK_START		_T("wf_startqs.htm")
#define FH_UPDATE_FILE		_T("wf_update.xml")
#define FH_UD_DELIM_START	_T("<updatestring string=\"")
#define FH_UD_DELIM_END		_T("\"/>")
#define FH_POST_WND			_T("wnd=")
#define FH_POST_CTX			_T("ctx=")
#define FH_POST_UPDATE		_T("update=")
#define FH_POST_PROJECT		_T("prj=")
#define FH_POST_HEADER		_T("Content-type: application/x-www-form-urlencoded\r\nContent-length: %s\r\n")
#define FH_UPDATE_INFO		_T("uid=%i>>cfi=%i>>sup=%i")

#define FH_WND_X				_T("x=")
#define FH_WND_Y				_T("y=")
#define FH_WND_WIDTH			_T("width=")
#define FH_WND_HEIGHT			_T("height=")
#define FH_WND_VIEW				_T("viewtype=")
#define FH_WND_WORK				_T("workspace=")
#define FH_WND_CAPTION			_T("caption=")

#define FH_WND_NAME				_T("wndname=")
#define FH_WND_DEFAULT			_T("wndusedef=")
#define FH_WND_TOOLBAR			_T("toolbar=")
#define FH_WND_LOCATIONBAR		_T("locationbar=")
#define FH_WND_MENU				_T("menu=")
#define FH_WND_RESIZE			_T("resizeable=")
#define FH_WND_STATUSBAR		_T("statusbar=")

#define FH_BROWSESEQ			_T("browsesequence=")
#define FH_SEARCHINPUT			_T("searchinput=")
#define FH_DEFAULTAGT			_T("defaultagent=")
#define FH_AGT					_T("agent=")
#define FH_CTXTOPIC				_T("ctxtopic=")
#define FH_UPDATE				_T("update=")

#define FH_SINGLE_PANE			_T("singlepane")
#define FH_DOUBLE_PANE			_T("doublepane")

#define FHWO_LOCATION			0x01		// location bar
#define FHWO_MENUBAR			0x02		// menubar		
#define FHWO_RESIZABLE			0x04		// resizable
#define FHWO_TOOLBAR			0x08		// toolbar
#define FHWO_STATUS				0x10		// statusbar

#define PANE_OPT_SEARCH			0x01		// search input
#define PANE_OPT_BROWSESEQ		0x02		// browse sequence

#define PARAM_LEN				20
#define MS_PARAM_LEN			100

/***************************************************************************************** 
	Constants and Static Variables
*****************************************************************************************/
#define DEFAULT_RH_TARGET_ID ""
#define AUTOCONTEXTID_PREFIX "HelpIdFromHTMLHelp"   // the prefix used to auto translate from topic number to context id
#define RH_TARGET_MANAGER	"RH_Target_Manager"
#define MAX_RH_URL_BUFLEN	 2048

static _TCHAR szTargetID[] = _T("__WebHelpCshStub");
static _TCHAR szRegisteredBrowserID[] = _T("__WebHelpCshRegistered");
static IWebBrowser2 *s_pRegisteredTopicBrowser = NULL;

//	static local variable
static _TCHAR s_szBrowserName[MAX_PATH] = _T("firefox");
static _TCHAR s_szRHSQuery[] = _T("?mgr=sys&cmd=ver");
static _TCHAR s_szRHSOldQuery[] =  _T("/robo/bin/robo.dll?mgr=sys&cmd=ver");
static int gbCoInited=0;

static CAxWindow *s_pAxWin = NULL;
static CAxWindow *s_pAxTopicWin = NULL;
static IWebBrowser2 *s_pstBrowser = NULL;
static HWND		s_hParent = NULL;
static _TCHAR szHelpTitle[] = _T(" - Help");

static IOleInPlaceActiveObject *s_pOleInPlaceActiveObject = NULL; 

#define ID_TOOLBAR		1000
#define ID_BACK			1001
#define ID_FORWARD		1002
#define ID_PRINT		1003

//	internal map
namespace utstd
{
 //_TCHAR strings
 typedef std::basic_string<_TCHAR> tstring;
 typedef std::map<utstd::tstring, utstd::tstring> map_tstring2tstring;
 typedef std::map<utstd::tstring, int> map_tstring2int;
 typedef std::set<utstd::tstring> set_tstring;
};
using namespace utstd;
static map_tstring2tstring helpSystemMap;
static map_tstring2tstring quickStartMap;
static map_tstring2int updateMap;
static set_tstring	unavailHelpSystemSet;
static set_tstring	checkedServers;




/***************************************************************************************** 
	Local Static Routines
*****************************************************************************************/
static int IsServerBased(const _TCHAR *a_pszUrlToHelpSet);
static int WH_ShowWebHelp(HWND hParent, const _TCHAR * pszHelpURL, const _TCHAR *pszWnd, unsigned int uCommand, DWORD dwData);
static int WH_ShowWebHelp_Server(HWND hParent, const _TCHAR * pszHelpURL, const _TCHAR *pszWnd, unsigned int uCommand, DWORD dwData);
static int WH_ShowFlashHelp_QS(HWND hParent, const _TCHAR * pszHelpURL, const _TCHAR *pszQuick, const _TCHAR *pszWnd, unsigned int uCommand, DWORD dwData, int nUpdate);
static int ShowWebHelp(HWND hParent, const _TCHAR * pszURL);

static unsigned int GetCommandForHelpSource(const _TCHAR *pszHelpSource, DWORD dwData);
static int ShowHelp(HWND hParent, const _TCHAR * pszHelpSource, unsigned int uCommand, DWORD dwData);
static int IsHtmlHelp(const _TCHAR * pszHelpSource);
static int IsWinHelp(const _TCHAR * pszHelpSource);
static int IsWebAddress(const _TCHAR * pszHelpSource);
static int LaunchProcess(const _TCHAR *a_pszAppExePath, _TCHAR *a_pszCommandLine);

void FH_URLEncode(_TCHAR* pszItem, unsigned int nSizeInWords);

static int IsServerAvailable(const _TCHAR * pszHelpSource);

static int WH_ShowHelp(HWND hParent, const _TCHAR * pszHelpSource, unsigned int uCommand, DWORD dwData);


#ifdef _WIN32
static int ShowHelpTopic_Win32(const _TCHAR *a_pszUrl);
static int ShowHelpTopic_Win32_IE(const _TCHAR *a_pszUrl);
static int ShowHelpTopic_Win32_NonIE(const _TCHAR *a_pszUrl);
static unsigned	GetTempFile(_TCHAR *a_pszTempUrl, unsigned uLength);
static unsigned PrepareTempHtmlFile(const _TCHAR*a_pszUrl, _TCHAR *a_pszTempUrl, unsigned uLength);
static IWebBrowser2* GetBrowser();
static IWebBrowser2* GetTopicBrowser();
static void AddIeEventListener(IWebBrowser2* pstBrowser, IDispatch *pDispatch);

#else
static int ShowHelpTopic_NonWin32(const _TCHAR *a_pszUrl);
#endif


/***************************************************************************************** 
	Context-Sensitive Help API
*****************************************************************************************/
void RH_AssociateOfflineHelp(const _TCHAR * a_pszPrimaryHelpSource, const _TCHAR * a_pszBackupHelpSource)
{
	tstring tPrimary = a_pszPrimaryHelpSource;
	tstring tBackup = a_pszBackupHelpSource;
	helpSystemMap[tPrimary] = tBackup;
}

void RH_AssociateQuickStart(const _TCHAR * a_pszPrimaryHelpSource, const _TCHAR * a_pszQuickStart, int nUpdate)
{
	tstring tPrimary = a_pszPrimaryHelpSource;
	tstring tQuickStart = a_pszQuickStart;
	quickStartMap[tPrimary] = tQuickStart;
	updateMap[tPrimary] = nUpdate;
}

int cleanObject()
{
	if (s_pstBrowser)
	{
		s_pstBrowser->Quit();
		s_pstBrowser->Release();
		s_pstBrowser=NULL;
	}
	if (s_pAxWin)
		delete s_pAxWin;
	if (s_pAxTopicWin)
		delete s_pAxTopicWin;
	return 0;
}

struct ThreadInfo
{
	LPCTSTR a_pszHelpFile;
	HINTERNET hSession;
	BOOL	bRet;
};

class FH_SvrInfo
{
public:
	FH_SvrInfo();
	~FH_SvrInfo();
	_TCHAR* GetFHOptionStr();
	_TCHAR* m_pszWndName;
	_TCHAR* m_pszXPos;
	_TCHAR* m_pszYPos;
	_TCHAR* m_pszUseDefWnd;
	_TCHAR* m_pszWidth;
	_TCHAR* m_pszHeight;
	_TCHAR* m_pszPanes;
	_TCHAR* m_pszWork;
	_TCHAR* m_pszCaption;
	int m_nWndProp;
	int m_nPaneProp;
	_TCHAR* m_pszDefault;
	_TCHAR* m_pszAgents;
	_TCHAR* m_pszCtxTopic;
	_TCHAR* m_pszUpdate;
};

FH_SvrInfo::FH_SvrInfo()
{
	m_pszWndName = NULL;
	m_pszXPos = NULL;
	m_pszYPos = NULL;
	m_pszWidth = NULL;
	m_pszHeight = NULL;
	m_pszWork = NULL;
	m_pszCaption = NULL;
	m_pszPanes = NULL;
	m_nWndProp = 0;
	m_nPaneProp = 0;
	m_pszDefault = NULL;
	m_pszAgents = NULL;
	m_pszCtxTopic = NULL;
	m_pszUpdate = NULL;
	m_pszUseDefWnd = NULL;
}

FH_SvrInfo::~FH_SvrInfo()
{
	if (m_pszAgents)
		delete[] m_pszAgents;
	if (m_pszCaption)
		delete[] m_pszCaption;
	if (m_pszCtxTopic)
		delete[] m_pszCtxTopic;
	if (m_pszDefault)
		delete[] m_pszDefault;
	if (m_pszHeight)
		delete[] m_pszHeight;
	if (m_pszWidth)
		delete[] m_pszWidth;
	if (m_pszPanes)
		delete[] m_pszPanes;
	if (m_pszWork)
		delete[] m_pszWork;
	if (m_pszXPos)
		delete[] m_pszXPos;
	if (m_pszYPos)
		delete[] m_pszYPos;
	if (m_pszUpdate)
		delete[] m_pszUpdate;
	if (m_pszUseDefWnd)
		delete[] m_pszUseDefWnd;
	if (m_pszWndName)
		delete[] m_pszWndName;
}

_TCHAR* FH_SvrInfo::GetFHOptionStr()
{
	_TCHAR* pResult = new _TCHAR[MAX_RH_URL_BUFLEN];
	pResult[0] = _T('\0');

	// write the name
	if (m_pszWndName)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN,  _T(">>wnm="));
		
		_tcscat_s(pResult,MAX_RH_URL_BUFLEN, m_pszWndName);
	}

	// write the x position
	if (m_pszXPos)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>x="));
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, m_pszXPos);
	}	
	// write the y position
	if (m_pszYPos)
	{
		_tcscat_s(pResult,  MAX_RH_URL_BUFLEN, _T(">>y="));
		_tcscat_s(pResult,  MAX_RH_URL_BUFLEN, m_pszYPos);
	}

	// write the width
	if (m_pszWidth)
	{
		_tcscat_s(pResult,MAX_RH_URL_BUFLEN, _T(">>dx="));
		_tcscat_s(pResult,MAX_RH_URL_BUFLEN, m_pszWidth);
	}
	
	// write the height
	if (m_pszHeight)
	{
		_tcscat_s(pResult,MAX_RH_URL_BUFLEN, _T(">>dy="));
		_tcscat_s(pResult,MAX_RH_URL_BUFLEN, m_pszHeight);
	}

	// write the value is use default
	if (m_pszUseDefWnd)
	{
		_tcscat_s(pResult,MAX_RH_URL_BUFLEN, _T(">>udw="));
		_tcscat_s(pResult,MAX_RH_URL_BUFLEN, m_pszUseDefWnd);
	}

	// write the window properties
	_TCHAR strTemp[MAX_PATH];
	_itot_s(m_nWndProp,strTemp,10);
	_tcscat_s(pResult,MAX_RH_URL_BUFLEN, _T(">>wot="));
	_tcscat_s(pResult,MAX_RH_URL_BUFLEN, strTemp);	

	// write the panes
	if (m_pszPanes)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>pan="));
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, m_pszPanes);
	}

	// write the workspace
	if (m_pszWork)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>wrk="));
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, m_pszWork);
	}

	// write the caption
	if (m_pszCaption)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>cap="));
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, m_pszCaption);
	}

	// write pane properties
	_itot_s(m_nPaneProp,strTemp,10);
	_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>pot="));
	_tcscat_s(pResult, MAX_RH_URL_BUFLEN, strTemp);

	// write the default agent
	if (m_pszDefault)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>pdb="));
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, m_pszDefault);
	}

	// write the agent order
	if (m_pszAgents)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>pbs="));
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, m_pszAgents);
	}

	// write the context topic
	if (m_pszCtxTopic)
	{
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, _T(">>url="));
		_tcscat_s(pResult, MAX_RH_URL_BUFLEN, m_pszCtxTopic);
	}

	FH_URLEncode(pResult, MAX_RH_URL_BUFLEN);

	return pResult;
}

void FH_URLEncode(_TCHAR* pszItem, unsigned int nSizeInWords)
{
	_TCHAR* pszNewItem = new _TCHAR[MAX_RH_URL_BUFLEN];
	_tcscpy_s(pszNewItem, MAX_RH_URL_BUFLEN, pszItem);

	// the % sign should always be the first character in the string
	_TCHAR pszChars[] = _T("%:/ ");

	for (int i = 0; i < _tcslen(pszChars); i++)
	{
		_TCHAR* pszNewString = new _TCHAR[MAX_RH_URL_BUFLEN];
		_TCHAR* pszStart = pszNewItem;
		_TCHAR* pszToken = _tcschr(pszNewItem,pszChars[i]);
		_TCHAR* charVal = new _TCHAR[MAX_PATH];

		int nVal = pszChars[i];

		_itot_s(nVal,charVal,MAX_PATH,16);

		pszNewString[0] = _T('\0');

		while (pszToken)
		{
			_tcsncat_s(pszNewString, MAX_RH_URL_BUFLEN, pszNewItem, pszToken - pszNewItem);
			_tcscat_s(pszNewString, MAX_RH_URL_BUFLEN, _T("%"));
			_tcscat_s(pszNewString,MAX_RH_URL_BUFLEN, charVal);
			
			pszNewItem = pszToken + 1;
			pszToken = _tcschr(pszNewItem,pszChars[i]);
		}

		_tcscat_s(pszNewString,MAX_RH_URL_BUFLEN, pszNewItem);
		delete[] pszStart;
		delete[] charVal;
		pszNewItem = pszNewString;
	}
	_tcscpy_s(pszItem, nSizeInWords, pszNewItem);
	delete[] pszNewItem;
}

////////////////////////////////////////////////////////////////////////////////
unsigned __stdcall RH_ThreadProc(void *p)
{
	ThreadInfo *pThreadInfo = (ThreadInfo *)p;
	
	INTERNET_PORT nServerPort = INTERNET_DEFAULT_HTTP_PORT;
	if (_tcsnicmp(pThreadInfo->a_pszHelpFile, _T("https://"), 8) == 0)
	{
		if (pThreadInfo)
			pThreadInfo->bRet = TRUE;
		return TRUE;
//		nServerPort = INTERNET_DEFAULT_HTTPS_PORT;
	}

	size_t nHostNameSize = _tcslen(pThreadInfo->a_pszHelpFile) + 1;
	_TCHAR * pHostName  = new _TCHAR[nHostNameSize];
	size_t nServerURLSize = _tcslen(pThreadInfo->a_pszHelpFile) + _tcslen(s_szRHSOldQuery) + 1;
	_TCHAR * pServerURL = new _TCHAR[nServerURLSize]; 

	LPCTSTR pBeginPos = _tcsstr(pThreadInfo->a_pszHelpFile, _T("//"));
	if (pBeginPos)
	{
		_tcscpy_s(pHostName, nHostNameSize, pBeginPos + 2);
		LPTSTR pEndPos = _tcsstr(pHostName, _T("/"));
		if (pEndPos)
		{
			_tcscpy_s(pServerURL, nServerURLSize, pEndPos);
			pEndPos[0] = '\0';
			LPTSTR pQueryPos = _tcsstr(pServerURL, _T("?"));
			if (pQueryPos)
				pQueryPos[0] = '\0';	
		}
		else
			pServerURL[0] = '\0';		
	}
	else
	{
		pHostName[0] = '\0';
		pServerURL[0] = '\0';
	}

	if (_tcslen(pHostName) > 0)
	{
		//extract port number, if any
		LPTSTR pPortPos = _tcsstr(pHostName, _T(":"));
		if (pPortPos)
		{
			nServerPort = _ttoi(pPortPos + 1);
			pPortPos[0] = '\0';
		}
		
		HINTERNET hConnect = InternetConnect(pThreadInfo->hSession,
											 pHostName,
											 nServerPort,
											 _T("csh"),
											 NULL,
											 INTERNET_SERVICE_HTTP,
											 0, 0);
		if (hConnect)
		{
			if (_tcslen(pServerURL) > 0)
				_tcsncat_s(pServerURL, nServerURLSize, s_szRHSQuery , _tcslen(s_szRHSQuery));	
			else
				_tcsncat_s(pServerURL, nServerURLSize, s_szRHSOldQuery , _tcslen(s_szRHSOldQuery));	

			HINTERNET hRequest = HttpOpenRequest(hConnect,
												 NULL,
												// _T("/robohelp/server?mgr=sys&cmd=ver"),
												pServerURL,
												 NULL,
												 NULL,
												 0, 0, 0);
			if (hRequest)
			{
				if (HttpSendRequest(hRequest, NULL, 0, NULL, 0))
				{
					_TCHAR httpBuffer[1024];
					DWORD dwHttpBufLen = 1024;
					DWORD dwHeader = 0;

					HttpQueryInfo(hRequest, HTTP_QUERY_RAW_HEADERS_CRLF,
											httpBuffer, &dwHttpBufLen, &dwHeader);

	#ifdef _UNICODE
					if (wcsstr(httpBuffer, _T("200 OK")))
	#else
					if (strstr(httpBuffer, _T("200 OK")))
	#endif
					{
						pThreadInfo->bRet = TRUE;
					}
					else
					{
						pThreadInfo->bRet = FALSE;
					}

				}
				else
				{
					pThreadInfo->bRet = FALSE;
				}
				InternetCloseHandle(hRequest);
			}
			InternetCloseHandle(hConnect);
		}
	}
	delete[] pHostName;
	delete[] pServerURL;

    _endthreadex(0);

    return 0;
}

static int IsServerAvailable(const _TCHAR * pszHelpSource)
{
  // check connection
    int nRet = 0;
    HANDLE hHandle;
    unsigned threadId;

    DWORD dwRet = InternetAttemptConnect(0);
    if (dwRet == ERROR_SUCCESS)
    {
        // check RoboHelp Server (http://help.server.com/robohelp/server)
        //_TCHAR s_szRequestVer[MAX_PATH];
        //    {
        //        CRegistry reg(HKEY_CURRENT_USER, REG_EHELP_RFT_BASEKEY);
        //        CString c_szRequestVer = reg.ReadString(REG_EHELP_RFT_REQVER, _T("http://help.server.com/robohelp/server?mgr=sys&cmd=ver"));
        //        _tcscpy(s_szRequestVer, c_szRequestVer);
        //    }
        // send URL: http://help.server.com/robohelp/server?mgr=sys&cmd=ver

        HINTERNET  hSession = InternetOpen( _T("Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 4.0)"), 
                                                INTERNET_OPEN_TYPE_PRECONFIG, 
                                                NULL, 
                                                NULL, 
                                                NULL );
        if (hSession)
        {
			ThreadInfo threadInfo;
			threadInfo.hSession  = hSession;
			threadInfo.a_pszHelpFile = pszHelpSource;
			threadInfo.bRet = FALSE;

            hHandle = (HANDLE)_beginthreadex(NULL, 4000, RH_ThreadProc, (void*)&threadInfo, 0, &threadId);
            WaitForSingleObject(hHandle, 3000);
            CloseHandle(hHandle);

			nRet = threadInfo.bRet;

            if (hSession) InternetCloseHandle(hSession);
        }
	}
	return nRet;
}

/*************************** Automatic CSH Generation::START ****************/
#include "Tlhelp32.h"
#define INVOKE_HELP 0x0200
#define APP_LAUNCHEDIN_CSHAUTHORING_MODE 0x0400
#define IS_PROCESSING_AUTO_CSH_REQUEST 0x0800
#define ROBO_HELP_HTML_APP_TITLE _T("RoboHelp HTML - ")
#define ROBO_HELP_EXE_NAME _T("RoboHTML.exe")
#define SHARED_MEM_NAME_BASE	_T("AUTO_CSH_ROBOHELP_AAB23446_B66C_47b0_9F93_58CE7B5E897E")
#define MAX_SHARED_NAME_LENGTH	MAX_PATH

typedef struct tagInvokeHelpData
{
	DWORD processID;
	DWORD dwMapID;
	wchar_t pszMapID[512];
	wchar_t pszTopicRelPath[512];
	wchar_t pszSharedName[MAX_SHARED_NAME_LENGTH];
} InvokeHelpData, *PInvokeHelpData;

typedef struct tagCSHAuthoringMode
{
	DWORD processID;
} CSHAuthoringMode, *PCSHAuthoringMode;

typedef struct tagFindMainWndOfProcess
{
	HWND hWnd;
	DWORD processID;
} FindMainWndOfProcess, *PFindMainWndOfProcess;

DWORD GetParentProcessID()
{
	DWORD ParentPID = 0;
	DWORD myPID = GetCurrentProcessId();

	PROCESSENTRY32 pe;
	memset(&pe, 0, sizeof(PROCESSENTRY32));
	pe.dwSize = sizeof(PROCESSENTRY32);

	HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if(Process32First(hSnapShot, &pe))
	{
		do {
			if(myPID == pe.th32ProcessID)
			{
				ParentPID = pe.th32ParentProcessID;
				break;
			}
		} while(Process32Next(hSnapShot, &pe));
	}
	CloseHandle(hSnapShot);

	return ParentPID;
}
BOOL CALLBACK EnumWindowCallBack(HWND hwnd, LPARAM lParam)
{ 
	PFindMainWndOfProcess p_fmwop = (PFindMainWndOfProcess)lParam;
	DWORD ProcessId = 0;
	GetWindowThreadProcessId(hwnd, &ProcessId);

	TCHAR lpTitle[256];
	::GetWindowText(hwnd, lpTitle, 256);
	lpTitle[_tcslen(ROBO_HELP_HTML_APP_TITLE)] = 0;
	if(ProcessId == p_fmwop->processID && 0 == _tcsicmp(lpTitle, ROBO_HELP_HTML_APP_TITLE))
	{
		p_fmwop->hWnd = hwnd; //Found
		return FALSE; //Stop enumerating
	}

	return TRUE;// Keep enumerating
}
HWND GetMainWindowFromProcess(DWORD ProcessID)
{
	FindMainWndOfProcess fmwop = {NULL, ProcessID};
	EnumWindows(EnumWindowCallBack, (LPARAM)&fmwop ) ;
	return fmwop.hWnd;
}
void InitializeHandleRoboHelp()
{
	BOOL bExeMatched = TRUE;

	DWORD dwParentRoboHelpID = GetParentProcessID();
	HANDLE hParentProcess = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ, FALSE, dwParentRoboHelpID);

	if(hParentProcess)
	{
		TCHAR szEXEPath[2048];

		if(GetModuleFileNameEx(	hParentProcess, NULL, szEXEPath, 2048 ))
		{
			TCHAR szName[256];
			TCHAR szExtension[256];
			_tsplitpath_s(szEXEPath, NULL, 0, NULL, 0, szName, 256, szExtension, 256);
			_tcscat_s(szName, szExtension);

			if( 0 != _tcsicmp( szName, ROBO_HELP_EXE_NAME))
			{
				bExeMatched = FALSE;
			}
		}
	}

	if(!bExeMatched)
		g_hRoboHelp = NULL;
	else
		g_hRoboHelp = GetMainWindowFromProcess(dwParentRoboHelpID);
}

HRESULT CheckIfRoboHelpProcessingOurRequest(HWND hHelpAppMainWnd)
{
	LRESULT returnValue = S_FALSE;

	if(!g_hRoboHelp || !::IsWindow(g_hRoboHelp))
		return E_FAIL;

	int sizeData = sizeof(COPYDATASTRUCT);
	int sizeIHData = sizeof(CSHAuthoringMode);

	HGLOBAL hMem = ::GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, sizeData+sizeIHData);
	if(!hMem || (::GlobalSize(hMem) < (sizeData+sizeIHData)))
		return E_OUTOFMEMORY;

	PCOPYDATASTRUCT pData = (PCOPYDATASTRUCT)hMem;
	PCSHAuthoringMode pIHData = (PCSHAuthoringMode)(pData + 1);

	pData->dwData = IS_PROCESSING_AUTO_CSH_REQUEST;
	pData->cbData = sizeIHData;
	pData->lpData = pIHData;

	pIHData->processID = GetCurrentProcessId();

	returnValue = ::SendMessage(g_hRoboHelp, WM_COPYDATA, (WPARAM)hHelpAppMainWnd, (LPARAM)(pData));
	GlobalFree(hMem);
	return returnValue;
}


HRESULT SendHelpMessageToRoboHelp(HWND hHelpAppMainWnd, DWORD dwMapID, const _TCHAR* pszMapID, const _TCHAR* pszTopicRelPath)
{
	if(!g_hRoboHelp || !::IsWindow(g_hRoboHelp))
		return E_FAIL;

	int sizeData = sizeof(COPYDATASTRUCT);
	int sizeIHData = sizeof(InvokeHelpData);

	HGLOBAL hMem = ::GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, sizeData+sizeIHData);
	if(!hMem || (::GlobalSize(hMem) < (sizeData+sizeIHData)))
		return E_OUTOFMEMORY;

	PCOPYDATASTRUCT pData = (PCOPYDATASTRUCT)hMem;
	PInvokeHelpData pIHData = (PInvokeHelpData)(pData + 1);

	pData->dwData = INVOKE_HELP;
	pData->cbData = sizeIHData;
	pData->lpData = pIHData;

	pIHData->processID = GetCurrentProcessId();
	pIHData->dwMapID = dwMapID;
	if(pszMapID)
	{
#ifdef UNICODE
		wcscpy_s(pIHData->pszMapID, 512, pszMapID);
#else
		MultiByteToWideChar(CP_ACP, 0, pszMapID , 512, pIHData->pszMapID, 512);
#endif
	}

	if(pszTopicRelPath)
	{
#ifdef UNICODE
		wcscpy_s(pIHData->pszTopicRelPath, 512, pszTopicRelPath);
#else

		MultiByteToWideChar(CP_ACP, 0, pszTopicRelPath , 512, pIHData->pszTopicRelPath, 512);
#endif
	}

	HWND hSelfWindowHandle = ::GetTopWindow(0);

	::SetWindowPos(g_hRoboHelp, hSelfWindowHandle, 0, 0,  0, 0, SWP_SHOWWINDOW|SWP_NOMOVE|SWP_NOSIZE);

	HANDLE hEvent = NULL;

	for( int counter=0; counter<100; counter++ )
	{
		wsprintfW(pIHData->pszSharedName, L"%s%d", SHARED_MEM_NAME_BASE, counter);
		hEvent = CreateEventW(
								NULL, 
								TRUE, 
								FALSE,
								pIHData->pszSharedName);
		if( hEvent == NULL )
			break;
		DWORD dwErr = GetLastError();
		if( ERROR_ALREADY_EXISTS == dwErr )
		{
			if( hEvent != NULL )
				CloseHandle(hEvent);
			continue;
		}
		break;
	}

	if(hEvent)
	{
		LRESULT hr = ::SendMessage(g_hRoboHelp, WM_COPYDATA, (WPARAM)hHelpAppMainWnd, (LPARAM)(pData));
		DWORD dwWaitResult;
		HANDLE  hObjects[1] = {hEvent};  // handles that need to be waited on 
		int     nObjects = 1;

		if(hr == S_OK)
		{
			while(true)
			{
				if(S_OK != CheckIfRoboHelpProcessingOurRequest(hHelpAppMainWnd))
					break;
				dwWaitResult = WaitForMultipleObjects(nObjects, hObjects, FALSE, 1000L * 60);
				if(WAIT_TIMEOUT == dwWaitResult)
					continue;
				else
					break;
			}
		}
	    CloseHandle(hEvent);
	}

	GlobalFree(hMem);
	return S_OK;
}

HRESULT CheckIfAppLaunchedFromRoboHelp(HWND hHelpAppMainWnd)
{
	LRESULT returnValue = FALSE;

	if(!g_hRoboHelp || !::IsWindow(g_hRoboHelp))
		return E_FAIL;

	int sizeData = sizeof(COPYDATASTRUCT);
	int sizeIHData = sizeof(CSHAuthoringMode);

	HGLOBAL hMem = ::GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, sizeData+sizeIHData);
	if(!hMem || (::GlobalSize(hMem) < (sizeData+sizeIHData)))
		return E_OUTOFMEMORY;

	PCOPYDATASTRUCT pData = (PCOPYDATASTRUCT)hMem;
	PCSHAuthoringMode pIHData = (PCSHAuthoringMode)(pData + 1);

	pData->dwData = APP_LAUNCHEDIN_CSHAUTHORING_MODE;
	pData->cbData = sizeIHData;
	pData->lpData = pIHData;

	pIHData->processID = GetCurrentProcessId();

	returnValue = ::SendMessage(g_hRoboHelp, WM_COPYDATA, (WPARAM)hHelpAppMainWnd, (LPARAM)(pData));

	GlobalFree(hMem);

	if(S_OK == returnValue)
		return S_OK;
	else
		return S_FALSE;
}

bool IsInCSHAuthoringMode(HWND hHelpAppMainWnd)
{
	static BOOL bCheckIsLaunchedFromRoboHelp = FALSE; 

	if(!bCheckIsLaunchedFromRoboHelp)
	{
		InitializeHandleRoboHelp();

		if(g_hRoboHelp && IsWindow(g_hRoboHelp))
		{
			if(S_OK == CheckIfAppLaunchedFromRoboHelp(hHelpAppMainWnd))
			{
				return TRUE;
			}
			else
			{
				g_hRoboHelp = NULL;
			}
		}
		else
		{
			g_hRoboHelp = NULL;
		}

		bCheckIsLaunchedFromRoboHelp = TRUE;
	}

	return (g_hRoboHelp && ::IsWindow(g_hRoboHelp));
}


/*************************** Automatic CSH Generation::END ******************/

int RH_OpenHelpTopic(const _TCHAR * a_pszHelpMainPage, const _TCHAR * a_pszTopicRelPath)
{
	if(IsInCSHAuthoringMode(NULL))
		return SendHelpMessageToRoboHelp(NULL, 0, NULL, a_pszTopicRelPath);

	int nRet = 0;
	static int nHookExit = 0;
	s_hParent = NULL;
	if (!nHookExit)
	{
		onexit(cleanObject);
		nHookExit = 1;
	}
	unsigned uLen = (unsigned)_tcslen(a_pszHelpMainPage);
	if (uLen)
	{
		_TCHAR *pszHelp = new _TCHAR[uLen + 1];
		_tcscpy_s(pszHelp, uLen + 1, a_pszHelpMainPage);
		_TCHAR *pWnd = _tcschr(pszHelp,'>');
		unsigned uWndLength = 0;
		if (pWnd)
		{
			*pWnd = '\0';
			pWnd++;
			uWndLength = (unsigned)_tcslen(pWnd) + _tcslen(_T(">>wnd="));
		}

		unsigned int uURLLength = _tcslen(pszHelp) + _tcslen(a_pszTopicRelPath) + _tcslen(_T("#<url=")) + uWndLength + 1;
		_TCHAR *pszURL = new _TCHAR[uURLLength];
		_tcscpy_s(pszURL, uURLLength, pszHelp);
		_tcscat_s(pszURL, uURLLength, _T("#<url="));
		_tcscat_s(pszURL, uURLLength, a_pszTopicRelPath);
		if (pWnd)
		{
			_tcscat_s(pszURL, uURLLength, _T(">>wnd="));
			_tcscat_s(pszURL, uURLLength,  pWnd);
		}
		nRet = ShowWebHelp(NULL, pszURL);
		delete[] pszURL;
		delete[] pszHelp;
	}
	return nRet;
}

int RH_ShowHelpForContext(HWND hParent, 
						 const _TCHAR * a_pszHelpFile, 
						 const _TCHAR *a_pszContext,
						 unsigned int uCommand, 
						 DWORD dwData
						)
{
	if(!a_pszHelpFile)
		return 0;
	unsigned uLen = (unsigned)_tcslen(a_pszHelpFile);
	if(uLen)
	{
		tstring sHelpSrc = a_pszHelpFile;
		if(a_pszContext && _tcslen(a_pszContext) > 0)
		{
			_TCHAR *pszHelp = new _TCHAR[uLen + 1];
			_tcscpy_s(pszHelp, uLen + 1, a_pszHelpFile);
			_TCHAR *pWnd = _tcschr(pszHelp,'>');
			if (pWnd)
			{
				*pWnd='\0';
				pWnd++;
			}
			_TCHAR slashCh = '/';
			_TCHAR *pMainPage = _tcsrchr(pszHelp, '/');
			if(!pMainPage)
			{
				pMainPage = _tcsrchr(pszHelp, '\\');
				slashCh = '\\';
			}

			*(pMainPage+1) = '\0';
			sHelpSrc = pszHelp;
			sHelpSrc += a_pszContext;
			sHelpSrc += slashCh;
			sHelpSrc += a_pszContext;
			sHelpSrc += _T(".htm");
			if(pWnd && _tcslen(pWnd) > 0)
			{
				sHelpSrc += '>';
				sHelpSrc += pWnd;
			}
			delete []pszHelp;
		}
		return RH_ShowHelp(hParent, sHelpSrc.c_str(), uCommand, dwData);
	}
	return 1;
}

int RH_ShowHelp(HWND hParent, const _TCHAR * a_pszHelpFile, unsigned int uCommand, DWORD dwData)
{
	if(IsInCSHAuthoringMode(hParent))
		return SendHelpMessageToRoboHelp(hParent, dwData, NULL, NULL);

	int nRet = 0;

	static int nHookExit = 0;

	s_hParent = hParent;

	if ((int) hParent == -1)
		hParent = NULL;

	if (!nHookExit)
	{
		onexit(cleanObject);
		nHookExit = 1;
	}

	// check if there is a backup help file for the one passed in.
	int nHasBackup = 1;
	tstring tPrimary = a_pszHelpFile;
	tstring tBackup = helpSystemMap[tPrimary];
	_TCHAR * pBackup = (_TCHAR*)tBackup.c_str();
	_TCHAR *pNewbackup = NULL;
	if (_tcslen(pBackup) == 0)
	{
		nHasBackup = 0;
		// if primary has window associated, then try strip out the window and find again.
		unsigned uLen = (unsigned)_tcslen(a_pszHelpFile);
		_TCHAR *pszHelp = new _TCHAR[uLen + 1];
		_tcscpy_s(pszHelp, uLen + 1, a_pszHelpFile);
		_TCHAR *pWnd = _tcschr(pszHelp,_T('>'));
		if (pWnd)
		{
			*pWnd='\0';
			pWnd++;
			tstring tPrimaryWithoutWnd = pszHelp;
			tstring tBackup2 = helpSystemMap[tPrimaryWithoutWnd];
			pBackup = (_TCHAR*)tBackup2.c_str();
			if (_tcslen(pBackup) != 0)
			{
				nHasBackup = 1;
				_TCHAR *pWnd2 = _tcschr(pBackup, '>');
				if (pWnd2 == NULL)
				{
					unsigned uLen = (unsigned)_tcslen(pBackup) + (unsigned)_tcslen(pWnd);
					pNewbackup = new _TCHAR [uLen + 2];
					_tcscpy_s(pNewbackup, uLen + 2, pBackup);
					_tcscat_s(pNewbackup, uLen + 2, _T(">"));
					_tcscat_s(pNewbackup, uLen + 2, pWnd);
					pBackup = pNewbackup;
				}
			}
		}
		delete[] pszHelp;
	}

	if (IsWebAddress(a_pszHelpFile))
	{
		int bAvailable = FALSE;
		DWORD dwFlags;
		if (InternetGetConnectedState(&dwFlags, 0))
		{
			if ((INTERNET_CONNECTION_MODEM & dwFlags) == 0)
			{
				if (IsServerBased(a_pszHelpFile))
				{
					if (checkedServers.find(tPrimary) == checkedServers.end())
					{
						bAvailable = IsServerAvailable(a_pszHelpFile);
						checkedServers.insert(tPrimary);
					}
					else
						bAvailable = TRUE;
				}
				else
					bAvailable = TRUE;
			}
		}
		if (!bAvailable)
			unavailHelpSystemSet.insert(tPrimary);
		else
			unavailHelpSystemSet.erase(tPrimary);
	}
	
	if (unavailHelpSystemSet.find(tPrimary) == unavailHelpSystemSet.end())
	{
		// attempt to show the help
		if (!ShowHelp(hParent, a_pszHelpFile, uCommand, dwData) != 0)
		{
			unavailHelpSystemSet.insert(tPrimary);
		}
		else
			nRet = 1;
	}

	if (!nRet)
	{
		// try the backup help system, if there is one
		if (nHasBackup)
		{
			// make sure we're using the appropriate command for the backup
			unsigned int uNewCommand = GetCommandForHelpSource(pBackup, dwData);
			if (uNewCommand != 0)
				uCommand = uNewCommand;

			nRet = ShowHelp(hParent, pBackup, uCommand, dwData);
		}
	}

	if (pNewbackup != NULL)
		delete[] pNewbackup;
		
	return nRet;
}


int RH_AIR_ShowHelp(const _TCHAR * a_pszViewerPath,
				const _TCHAR * a_pszHelpId,
				const _TCHAR * a_pszWindowName,
				unsigned long ulMapNum,
				const _TCHAR * a_pszMapId,
				const _TCHAR * a_pszTopicURL)
{
	if(IsInCSHAuthoringMode(NULL))
		return SendHelpMessageToRoboHelp(NULL, ulMapNum, a_pszMapId, a_pszTopicURL);

	_TCHAR cmdParam[2048];
	int iRetVal = 1;

	if(!::PathFileExists(a_pszViewerPath))
		return iRetVal;;
	
	_tcscpy_s(cmdParam, 2048, _T(" -csh"));
	if(a_pszHelpId != NULL && _tcslen(a_pszHelpId) > 0)
	{
		_tcscat_s(cmdParam, 2048, _T(" helpid \""));
		_tcscat_s(cmdParam, 2048, a_pszHelpId);
		_tcscat_s(cmdParam, 2048, _T("\""));
	}

	if(a_pszWindowName!=NULL && _tcslen(a_pszWindowName)>0)
	{
		_tcscat_s(cmdParam, 2048, _T(" window \""));
		_tcscat_s(cmdParam, 2048, a_pszWindowName);
		_tcscat_s(cmdParam, 2048, _T("\""));
	}

	if(a_pszTopicURL)
	{
		_tcscat_s(cmdParam, 2048, _T(" topicurl \""));
		_tcscat_s(cmdParam, 2048, a_pszTopicURL);
		_tcscat_s(cmdParam, 2048, _T("\""));
	}
	else if(a_pszMapId)
	{
		_tcscat_s(cmdParam, 2048, _T(" mapid \""));
		_tcscat_s(cmdParam, 2048, a_pszMapId);
		_tcscat_s(cmdParam, 2048, _T("\""));
	}
	else
	{
		_TCHAR szTemp[MAX_PATH];
		_itot_s(ulMapNum, szTemp, MAX_PATH, 10);
		_tcscat_s(cmdParam, 2048, _T(" mapnumber "));
		_tcscat_s(cmdParam, 2048, szTemp);
	}

	iRetVal = LaunchProcess(a_pszViewerPath, cmdParam);
	
	return iRetVal;
}

/***************************************************************************************** 
	Helper functions
*****************************************************************************************/
int ShowHelp(HWND hParent, const _TCHAR * pszHelpSource, unsigned int uCommand, DWORD dwData)
{
	int nRet = 0;
	if (IsWinHelp(pszHelpSource))
	{
		switch (uCommand)
		{
		case HH_HELP_CONTEXT:
			uCommand = HELP_CONTEXT;
			break;
		default:
			break;
		}
		::WinHelp(hParent, pszHelpSource, uCommand, dwData);
		nRet = 1;
	}
	else if (IsHtmlHelp(pszHelpSource))
	{
		::HtmlHelp(hParent, pszHelpSource, uCommand, dwData);
		nRet = 1;
	}
	
	else
	{
		WH_ShowHelp(hParent, pszHelpSource, uCommand, dwData);
		nRet = 1;
	}
	return nRet;
}

int WH_ShowHelp(HWND hParent, const _TCHAR * pszHelpSource, unsigned int uCommand, DWORD dwData)
{
	int nRet = 0;
	if (pszHelpSource)
	{
		unsigned uLen = (unsigned)_tcslen(pszHelpSource);
		if (uLen)
		{
			_TCHAR *pszHelp = new _TCHAR[uLen + 1];
			_tcscpy_s(pszHelp, uLen + 1, pszHelpSource);
			_TCHAR *pWnd = _tcschr(pszHelp,'>');
			if (pWnd)
			{
				*pWnd='\0';
				pWnd++;
			}

			if (IsServerBased(pszHelp))
			{
				// check for quickstart files
				tstring tPrimary = pszHelp;
				tstring tQuickStart = quickStartMap[tPrimary];

				const _TCHAR * pszQuick = (_TCHAR*) tQuickStart.c_str();
				int nUpdate = updateMap[tPrimary];

				// If quickstart files are defined, display using QuickStart
				if (_tcslen(pszQuick) > 0)
				{
					nRet = WH_ShowFlashHelp_QS(hParent, pszHelp, pszQuick, pWnd, uCommand, dwData, nUpdate);
					// If we fail try loading without the quickstart files
					if (nRet == 0)
					{
						nRet = WH_ShowWebHelp_Server(hParent, pszHelp, pWnd, uCommand, dwData);
					}

				}
				else
				{
					nRet = WH_ShowWebHelp_Server(hParent, pszHelp, pWnd, uCommand, dwData);
				}
			}
			else
			{
				nRet = WH_ShowWebHelp(hParent, pszHelp, pWnd, uCommand, dwData);
			}
			delete []pszHelp;
		}
	}
	return nRet;
}

int WH_ShowWebHelp(HWND hParent, const _TCHAR * pszHelpURL, const _TCHAR *pszWnd, unsigned int uCommand, DWORD dwData)
{
	int nRet = 0;
	_TCHAR szParam[PARAM_LEN];
	switch (uCommand)
	{
	case HH_DISPLAY_TOPIC:
		{
			_tcscpy_s(szParam, PARAM_LEN, _T("#<id=0"));
		}
		break;
	case HH_HELP_CONTEXT:
		{
			int nId = dwData;
			// Fixed Bug# 
			if(nId == 0) return 1;
			_stprintf_s(szParam, PARAM_LEN, _T("#<id=%d"), nId);
		}
		break;
	case HH_DISPLAY_INDEX:
		{
			_stprintf_s(szParam, PARAM_LEN, _T("#<cmd=idx"));
		}
		break;
	case HH_DISPLAY_SEARCH:
		{
			_stprintf_s(szParam, PARAM_LEN, _T("#<cmd=fts"));
		}
		break;
	case HH_DISPLAY_TOC:
		{
			_stprintf_s(szParam, PARAM_LEN, _T("#<cmd=toc"));
		}
		break;
	}
	if (_tcslen(szParam)!=0)
	{
		unsigned uWndLength = 0;
		if (pszWnd)
			uWndLength = (unsigned)_tcslen(pszWnd) + 6;

		unsigned int uHelpURLLength =  _tcslen(pszHelpURL) + _tcslen(szParam) + uWndLength + 1;
		_TCHAR *pszURL=new _TCHAR[uHelpURLLength];
		_tcscpy_s(pszURL, uHelpURLLength, pszHelpURL);
		_tcscat_s(pszURL,uHelpURLLength, szParam);
		if (pszWnd)
		{
			_tcscat_s(pszURL, uHelpURLLength, _T(">>wnd="));
			_tcscat_s(pszURL, uHelpURLLength, pszWnd);
		}
		nRet = ShowWebHelp(hParent, pszURL);
		delete[] pszURL;
	}
	return nRet;
}

int RH_Show_BrowserBasedHelp(HWND hParent, 
							 const _TCHAR * pszHelpURL,
							 const _TCHAR *pszContext,
							 const _TCHAR *pszWnd,
							 unsigned int uCommand,
							 DWORD dwData
							 )
{
	if(IsInCSHAuthoringMode(hParent))
		return SendHelpMessageToRoboHelp(hParent, dwData, NULL, NULL);

	int nRet = 0;
	_TCHAR szParam[PARAM_LEN];
	switch (uCommand)
	{
	case HH_DISPLAY_TOPIC:
		{
			_tcscpy_s(szParam, PARAM_LEN, _T("#<id=0"));
		}
		break;
	case HH_HELP_CONTEXT:
		{
			int nId = dwData;
			// Fixed Bug# 
			if(nId == 0) return 1;
			_stprintf_s(szParam, PARAM_LEN, _T("#<id=%d"), nId);
		}
		break;
	case HH_DISPLAY_INDEX:
		{
			_stprintf_s(szParam, PARAM_LEN, _T("#<cmd=idx"));
		}
		break;
	case HH_DISPLAY_SEARCH:
		{
			_stprintf_s(szParam, PARAM_LEN, _T("#<cmd=fts"));
		}
		break;
	case HH_DISPLAY_TOC:
		{
			_stprintf_s(szParam, PARAM_LEN, _T("#<cmd=toc"));
		}
		break;
	}

	if (_tcslen(szParam)!=0)
	{
		unsigned uWndLength = 0;
		unsigned uContextLength = 0;
		if (pszWnd)
			uWndLength = (unsigned)_tcslen(pszWnd) + 6;
		if(pszContext)
			uContextLength = (unsigned)_tcslen(pszContext) + 10;

		unsigned int uURLLength = _tcslen(pszHelpURL) + _tcslen(szParam) + uWndLength + uContextLength + 1;
		_TCHAR *pszURL=new _TCHAR[uURLLength];
		_tcscpy_s(pszURL, uURLLength, pszHelpURL);
		_tcscat_s(pszURL, uURLLength,  szParam);
		if (pszWnd && _tcslen(pszWnd) > 0)
		{
			_tcscat_s(pszURL, uURLLength, _T(">>wnd="));
			_tcscat_s(pszURL, uURLLength, pszWnd);
		}
		if(pszContext && _tcslen(pszContext) > 0)
		{
			_tcscat_s(pszURL, uURLLength, _T(">>helpid="));
			_tcscat_s(pszURL, uURLLength, pszContext);
		}
		nRet = ShowWebHelp(hParent, pszURL);
		delete[] pszURL;
	}
	return nRet;
}

int RH_ShowMultiscreenHelpWithMapNo(HWND hParent, 
							 const _TCHAR *pszHelpURL,
							 const _TCHAR *pszWnd,
							 DWORD dwMapNo/*=0*/
							 )
{
	if(IsInCSHAuthoringMode(hParent))
		return SendHelpMessageToRoboHelp(hParent, dwMapNo, NULL, NULL);

	int nRet = 0;

	if(!pszHelpURL)
		return nRet;
	_TCHAR szParam[MS_PARAM_LEN];
	_tcscpy_s(szParam, MS_PARAM_LEN, _T("?rhnewwnd=1&rhcsh=1"));


	if(pszWnd && _tcscmp(pszWnd, _T(""))!=0)
	{
		_tcscat_s(szParam, MS_PARAM_LEN, _T("&"));
		_tcscat_s(szParam, MS_PARAM_LEN, _T("rhwnd="));
		_tcscat_s(szParam, MS_PARAM_LEN, pszWnd);
	}
	int nId = dwMapNo;
	if(nId > 0)
	{
		_TCHAR szId[PARAM_LEN];
		_tcscat_s(szParam, MS_PARAM_LEN, _T("&"));
		_stprintf_s(szId, PARAM_LEN, _T("rhmapno=%d"), nId);
		_tcscat_s(szParam, MS_PARAM_LEN, szId);
	}

	unsigned int uURLLength = _tcslen(pszHelpURL) + _tcslen(szParam) + 1;
	_TCHAR *pszURL=new _TCHAR[uURLLength];
	_tcscpy_s(pszURL, uURLLength, pszHelpURL);
	_tcscat_s(pszURL, uURLLength,  szParam);

	nRet = ShowWebHelp(hParent, pszURL);
	delete[] pszURL;

	return nRet;
}

int RH_ShowMultiscreenHelpWithMapId(HWND hParent, 
							 const _TCHAR *pszHelpURL,
							 const _TCHAR *pszWnd,
							 const _TCHAR *pszMapId/*=NULL*/
							 )
{

	int nRet = 0;

	if(!pszHelpURL)
		return nRet;
	_TCHAR szParam[MS_PARAM_LEN];
	_tcscpy_s(szParam, MS_PARAM_LEN, _T("?rhnewwnd=1&rhcsh=1"));


	if(pszWnd && _tcscmp(pszWnd, _T(""))!=0)
	{
		_tcscat_s(szParam, MS_PARAM_LEN, _T("&"));
		_tcscat_s(szParam, MS_PARAM_LEN, _T("rhwnd="));
		_tcscat_s(szParam, MS_PARAM_LEN, pszWnd);
	}
	if(pszMapId && _tcscmp(pszMapId, _T(""))!=0)
	{
		_tcscat_s(szParam, MS_PARAM_LEN, _T("&"));
		_tcscat_s(szParam, MS_PARAM_LEN, _T("rhmapid="));
		_tcscat_s(szParam, MS_PARAM_LEN, pszMapId);
	}

	unsigned int uURLLength = _tcslen(pszHelpURL) + _tcslen(szParam) + 1;
	_TCHAR *pszURL=new _TCHAR[uURLLength];
	_tcscpy_s(pszURL, uURLLength, pszHelpURL);
	_tcscat_s(pszURL, uURLLength,  szParam);

	nRet = ShowWebHelp(hParent, pszURL);
	delete[] pszURL;

	return nRet;
}


int RH_ProcessKeyStrokes(MSG* pMsg)
{
	int nRet = 1;
	if ( pMsg->message == WM_KEYUP || (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN))
	{
		IWebBrowser2* pBrowser = GetTopicBrowser();
		if(pBrowser && s_pOleInPlaceActiveObject)
		{
			s_pOleInPlaceActiveObject->TranslateAcceleratorW(pMsg);
			TranslateMessage(pMsg); 	
			DispatchMessage(pMsg);
			nRet = 0;
			return nRet;
		}
	}
	return nRet;
}
int ShowWebHelp(HWND /*hParent*/, const _TCHAR *pszURL)
{
	// hParent not supported.
	int nRet = 0;
	// MORE:
#ifdef _WIN32
	nRet = ShowHelpTopic_Win32(pszURL);
#else
	nRet = ShowHelpTopic_NonWin32(pszURL);
#endif
	return nRet;
}

_TCHAR* FH_GetUpdateString(const _TCHAR * pszHelpURL)
{
	unsigned int uUpdateLen = _tcslen(pszHelpURL)+ _tcslen(FH_UPDATE_FILE) + 1;
	_TCHAR* pszUpdate = new _TCHAR[uUpdateLen];
	_tcscpy_s(pszUpdate, uUpdateLen, pszHelpURL);
	_tcscat_s(pszUpdate, uUpdateLen, FH_UPDATE_FILE);
	pszUpdate[_tcslen(pszHelpURL)+ _tcslen(FH_UPDATE_FILE)] = _T('\0');


	_TCHAR* pszResult = NULL;

	HANDLE hUpdateFile = CreateFile(pszUpdate,
									GENERIC_READ,
									FILE_SHARE_READ | FILE_SHARE_WRITE,
									NULL,
									OPEN_EXISTING,
									NULL,
									NULL);

	if (hUpdateFile != INVALID_HANDLE_VALUE)
	{
		_TCHAR buffer[MAX_PATH+1];
		_tcsnset_s(buffer, MAX_PATH+1, _T('\0'), MAX_PATH+1);
		_TCHAR* pszUpdateString = NULL;
		DWORD dwCount = MAX_PATH;
		DWORD dwSize = 0;
		_TCHAR* pszTemp = NULL;
		BOOL bFound = false;

		// read the file until the required section is found
		while (ReadFile(hUpdateFile,buffer, MAX_PATH, &dwCount, NULL) && dwCount > 0 && !bFound)
		{
			dwSize += dwCount+1;
			pszTemp = new _TCHAR[dwSize];
			_tcsnset_s(pszTemp, dwSize, _T('\0'), dwSize);

			if (pszUpdateString != NULL)
			{
				_tcscpy_s(pszTemp, dwSize, pszUpdateString);
				delete[] pszUpdateString;
			}

			_tcscat_s(pszTemp, dwSize, buffer);
			pszUpdateString = pszTemp;
			
			// Search for the start of the update string
			_TCHAR* pszSub1 = _tcsstr(pszUpdateString, FH_UD_DELIM_START);
			pszSub1 += _tcslen(FH_UD_DELIM_START);
			
			if (pszSub1 != NULL)
			{
				// Search for the end of the update string
				_TCHAR* pszSub2 = _tcsstr(pszSub1, FH_UD_DELIM_END);
				if (pszSub2 != NULL)
				{
					DWORD dwCount = pszSub2 - pszSub1;
					
					pszResult = new _TCHAR[dwCount+1];
					_tcsnset_s(pszResult, dwCount+1, _T('\0'), dwCount+1);
					
					_tcsncpy_s(pszResult, dwCount+1, pszSub1, dwCount);
					
					bFound = true;
				}
			}
			_tcsnset_s(buffer, MAX_PATH+1, _T('\0'), MAX_PATH+1);
		}

		if (pszUpdateString != NULL)
		{
			delete[] pszUpdateString;
			pszUpdateString = NULL;
		}

		CloseHandle(hUpdateFile);
	}

	delete[] pszUpdate;
	return pszResult;
}

_TCHAR* FH_PostUpdateData(const _TCHAR * pszHelpFile, const _TCHAR * pszHeader, const _TCHAR * pszPostData)
{
	_TCHAR* pszResult = NULL;

	HINTERNET  hSession = InternetOpen( _T("Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 4.0)"), 
										INTERNET_OPEN_TYPE_PRECONFIG, 
										NULL, 
										NULL, 
										NULL );
	if (hSession)
	{
		unsigned int nHostNameSize = _tcslen(pszHelpFile) + 1;
		_TCHAR * pHostName  = new _TCHAR[nHostNameSize];

		LPCTSTR pBeginPos = _tcsstr(pszHelpFile, _T("//"));
		if (pBeginPos)
		{
			_tcscpy_s(pHostName, nHostNameSize, pBeginPos + 2);
			LPTSTR pEndPos = _tcsstr(pHostName, _T("/"));
			if (pEndPos)
				pEndPos[0] = '\0';
			else
				pHostName[0] = '\0';
		}
		else
			pHostName[0] = '\0';

		if (_tcslen(pHostName) > 0)
		{

			HINTERNET hConnect = InternetConnect(hSession,
												 pHostName,
												 INTERNET_DEFAULT_HTTP_PORT,
												 _T("csh"),
												 NULL,
												 INTERNET_SERVICE_HTTP,
												 0, 0);
			if (hConnect)
			{
				HINTERNET hRequest = HttpOpenRequest(hConnect,
													 _T("POST"),
													 _T("?mgr=sys&cmd=updinf"),
													 NULL,
													 NULL,
													 0, 0, 0);
				if (hRequest)
				{
					if (HttpSendRequest(hRequest, pszHeader, _tcslen(pszHeader), (void*) pszPostData, _tcslen(pszPostData)))
					{
						_TCHAR httpBuffer[1024];
						DWORD dwHttpBufLen = 1024;
						DWORD dwHeader = 0;


						HttpQueryInfo(hRequest, HTTP_QUERY_RAW_HEADERS_CRLF,
												httpBuffer, &dwHttpBufLen, &dwHeader);

		#ifdef _UNICODE
						if (wcsstr(httpBuffer, _T("200 OK")))
		#else
						if (strstr(httpBuffer, _T("200 OK")))
		#endif
						{
							// Read the downloaded data
							_TCHAR buffer[MAX_PATH+1];
							_tcsnset_s(buffer, MAX_PATH+1, _T('\0'), MAX_PATH+1);
							DWORD dwCount = 0;
							DWORD dwSize = 0;
							_TCHAR* pszTemp = NULL;
							while(InternetReadFile( hRequest, buffer, MAX_PATH, &dwCount) && dwCount > 0)
							{
								dwSize += dwCount+1;
								pszTemp = new _TCHAR[dwSize];
								_tcsnset_s(pszTemp, dwSize, _T('\0'), dwSize);

								if (pszResult != NULL)
								{
									_tcscpy_s(pszTemp, dwSize, pszResult);
									delete[] pszResult;
								}

								_tcscat_s(pszTemp,dwSize, buffer);
								pszResult = pszTemp;
								_tcsnset_s(buffer, MAX_PATH+1, _T('\0'), MAX_PATH+1);
							}
							char count[256];
							_itoa_s(dwCount,count,256,10);
						}
					}
					InternetCloseHandle(hRequest);
				}
				InternetCloseHandle(hConnect);
			}
			InternetCloseHandle(hSession);
		}
		delete[] pHostName;
	}

	return pszResult;
}

FH_SvrInfo* FH_ParseSvrInfo(const _TCHAR * pszServerInfo)
{
	FH_SvrInfo* pSvrInfo = new FH_SvrInfo();
	_TCHAR* pszStart = NULL;
	unsigned int nLenServerInfo = _tcslen(pszServerInfo);
	_TCHAR* pszSvrStr = new _TCHAR[nLenServerInfo+1];
	_tcscpy_s(pszSvrStr, nLenServerInfo+1, pszServerInfo);
	pszSvrStr[nLenServerInfo] = _T('\0');
	pszStart = pszSvrStr;

	while (pszSvrStr != NULL)
	{
		_TCHAR* pszTemp = _tcsstr(pszSvrStr, _T("\n"));
		if (pszTemp != NULL)
		{
			// Get the current item
			_TCHAR* pszItem = new _TCHAR[(pszTemp - pszSvrStr)+1];
			_tcsncpy_s(pszItem, (pszTemp - pszSvrStr)+1, pszSvrStr, pszTemp - pszSvrStr);
			pszItem[pszTemp - pszSvrStr -1] = '\0';

			// Get the data
			_TCHAR* pszData = _tcsstr(pszItem, _T("="));
			if (pszData)
			{
				// Increment past the equal sign
				pszData++;
				unsigned int nLenData = _tcslen(pszData);
				_TCHAR* pszNewData = new _TCHAR[nLenData+1];
				_tcscpy_s(pszNewData, nLenData+1, pszData);
				pszNewData[nLenData] = _T('\0');
				// Store the information
				if (_tcsstr(pszItem, FH_WND_NAME))
				{
					pSvrInfo->m_pszWndName = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_X))
				{
					pSvrInfo->m_pszXPos = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_Y))
				{
					pSvrInfo->m_pszYPos = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_WIDTH))
				{
					pSvrInfo->m_pszWidth = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_HEIGHT))
				{
					pSvrInfo->m_pszHeight = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_VIEW))
				{
					_TCHAR* pszPane= new _TCHAR[2];
					pszPane[1] = _T('\0');
					if (_tcsstr(pszNewData, FH_SINGLE_PANE))
					{
						pszPane[0] = _T('1');
					}
					else
					{
						pszPane[0] = _T('2');
					}
					pSvrInfo->m_pszPanes = pszPane;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_WORK))
				{
					pSvrInfo->m_pszWork = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_CAPTION))
				{
					pSvrInfo->m_pszCaption = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_TOOLBAR))
				{
					pSvrInfo->m_nWndProp += _ttoi(pszNewData) * FHWO_TOOLBAR;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_LOCATIONBAR))
				{
					pSvrInfo->m_nWndProp += _ttoi(pszNewData) * FHWO_LOCATION;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_MENU))
				{
					pSvrInfo->m_nWndProp += _ttoi(pszNewData) * FHWO_MENUBAR;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_RESIZE))
				{
					pSvrInfo->m_nWndProp += _ttoi(pszNewData) * FHWO_RESIZABLE;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_STATUSBAR))
				{
					pSvrInfo->m_nWndProp += _ttoi(pszNewData) * FHWO_STATUS;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_BROWSESEQ))
				{
					pSvrInfo->m_nPaneProp += _ttoi(pszNewData) * PANE_OPT_BROWSESEQ;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_WND_DEFAULT))
				{
					pSvrInfo->m_pszUseDefWnd = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_SEARCHINPUT))
				{
					pSvrInfo->m_nPaneProp += _ttoi(pszNewData) * PANE_OPT_SEARCH;
					delete[] pszNewData;
				}
				else if (_tcsstr(pszItem, FH_DEFAULTAGT))
				{
					pSvrInfo->m_pszDefault = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_AGT))
				{
					if (pSvrInfo->m_pszAgents == NULL)
					{
						pSvrInfo->m_pszAgents = pszNewData;
					}
					else
					{
						int nLen = _tcslen(pSvrInfo->m_pszAgents)+ _tcslen(pszNewData) + 2;
						_TCHAR* pszAgentsNew = new _TCHAR[nLen];
						_tcsnset_s(pszAgentsNew, nLen, _T('\0'), nLen);
						_tcscpy_s(pszAgentsNew, nLen, pSvrInfo->m_pszAgents);
						_tcscat_s(pszAgentsNew, nLen, _T("|"));
						_tcscat_s(pszAgentsNew, nLen, pszNewData);
						delete[] pSvrInfo->m_pszAgents;
						delete[] pszNewData;
						pSvrInfo->m_pszAgents = pszAgentsNew;
					}
				}
				else if (_tcsstr(pszItem, FH_CTXTOPIC))
				{
					pSvrInfo->m_pszCtxTopic = pszNewData;
				}
				else if (_tcsstr(pszItem, FH_UPDATE))
				{
					if (pSvrInfo->m_pszUpdate == NULL)
					{
						pSvrInfo->m_pszUpdate = new _TCHAR(_T('\0'));
					}
					int nLen = _tcslen(pSvrInfo->m_pszUpdate)+ _tcslen(pszNewData) + 2;
					_TCHAR* pszUpdateNew = new _TCHAR[nLen];
					_tcsnset_s(pszUpdateNew, nLen, _T('\0'), nLen);
					_tcscpy_s(pszUpdateNew, nLen, pSvrInfo->m_pszUpdate);
					_tcscat_s(pszUpdateNew, nLen, pszNewData);
					_tcscat_s(pszUpdateNew, nLen, _T("|"));
					delete[] pSvrInfo->m_pszUpdate;
					delete[] pszNewData;
					pSvrInfo->m_pszUpdate = pszUpdateNew;
				}
				else
				{
					delete[] pszNewData;
				}
			}
			// Increment past the newline
			pszTemp++;
			delete[] pszItem;
		}
		pszSvrStr = pszTemp;
	}

	delete[] pszStart;

	return pSvrInfo;
}

//////////////////////////////////////////////////////////////////////////////
#ifdef _WIN32
GUID RH_IID_ITargetFrame2 =      {0x86D52E11,  0x94A8, 0x11d0, {0x82,0xAF,0x00,0xC0,0x4F,0xD5,0xAE,0x38}};

interface RH_ITargetFrame2 : public IUnknown
{
public:
    virtual HRESULT STDMETHODCALLTYPE SetFrameName( 
        /* [in] */ LPCWSTR pszFrameName) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE GetFrameName( 
        /* [out] */ LPWSTR __RPC_FAR *ppszFrameName) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE GetParentFrame( 
        /* [out] */ IUnknown __RPC_FAR *__RPC_FAR *ppunkParent) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE SetFrameSrc( 
        /* [in] */ LPCWSTR pszFrameSrc) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE GetFrameSrc( 
        /* [out] */ LPWSTR __RPC_FAR *ppszFrameSrc) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE GetFramesContainer( 
        /* [out] */ IOleContainer __RPC_FAR *__RPC_FAR *ppContainer) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE SetFrameOptions( 
        /* [in] */ DWORD dwFlags) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE GetFrameOptions( 
        /* [out] */ DWORD __RPC_FAR *pdwFlags) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE SetFrameMargins( 
        /* [in] */ DWORD dwWidth,
        /* [in] */ DWORD dwHeight) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE GetFrameMargins( 
        /* [out] */ DWORD __RPC_FAR *pdwWidth,
        /* [out] */ DWORD __RPC_FAR *pdwHeight) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE FindFrame( 
        /* [unique][in] */ LPCWSTR pszTargetName,
        /* [in] */ DWORD dwFlags,
        /* [out] */ IUnknown __RPC_FAR *__RPC_FAR *ppunkTargetFrame) = 0;
    
    virtual HRESULT STDMETHODCALLTYPE GetTargetAlias( 
        /* [unique][in] */ LPCWSTR pszTargetName,
        /* [out] */ LPWSTR __RPC_FAR *ppszTargetAlias) = 0;
    
};



GUID RH_IID_IHTMLWindow3 =      {0x3050F4AE,  0x98B5, 0x11CF, {0xBB,0x82,0x00,0xAA,0x00,0xBD,0xCE,0x0B}};


interface RH_IHTMLWindow3 : public IDispatch
{
public:
    virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_screenLeft( 
        /* [out][retval] */ long *p) = 0;
    
    virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_screenTop( 
        /* [out][retval] */ long *p) = 0;
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE attachEvent( 
        /* [in] */ BSTR event,
        /* [in] */ IDispatch *pDisp,
        /* [out][retval] */ VARIANT_BOOL *pfResult) = 0;
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE detachEvent( 
        /* [in] */ BSTR event,
        /* [in] */ IDispatch *pDisp) = 0;
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE setTimeout( 
        /* [in] */ VARIANT *expression,
        /* [in] */ long msec,
        /* [in][optional] */ VARIANT *language,
        /* [out][retval] */ long *timerID) = 0;
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE setInterval( 
        /* [in] */ VARIANT *expression,
        /* [in] */ long msec,
        /* [in][optional] */ VARIANT *language,
        /* [out][retval] */ long *timerID) = 0;
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE print( void) = 0;
    
    virtual /* [bindable][displaybind][id][propput] */ HRESULT STDMETHODCALLTYPE put_onbeforeprint( 
        /* [in] */ VARIANT v) = 0;
    
    virtual /* [bindable][displaybind][id][propget] */ HRESULT STDMETHODCALLTYPE get_onbeforeprint( 
        /* [out][retval] */ VARIANT *p) = 0;
    
    virtual /* [bindable][displaybind][id][propput] */ HRESULT STDMETHODCALLTYPE put_onafterprint( 
        /* [in] */ VARIANT v) = 0;
    
    virtual /* [bindable][displaybind][id][propget] */ HRESULT STDMETHODCALLTYPE get_onafterprint( 
        /* [out][retval] */ VARIANT *p) = 0;
    
    virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_clipboardData( 
        /* [out][retval] */ void /*IHTMLDataTransfer*/ **p) = 0;
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE showModelessDialog( 
        /* [in][defaultvalue] */ BSTR url,
        /* [in][optional] */ VARIANT *varArgIn,
        /* [in][optional] */ VARIANT *options,
        /* [out][retval] */ IHTMLWindow2 **pDialog) = 0;
    
};

IWebBrowser2* GetBrowser() 
{
	IWebBrowser2 *pBrowser = NULL;
	// If the caller already initialize COM, please comment out the next 5 lines.
	if (!gbCoInited)
	{
		::CoInitialize(NULL);
		gbCoInited=1;
	}

	if (!s_pAxWin)
	{
		AtlAxWinInit();
		s_pAxWin = new CAxWindow;
		RECT rect;
		rect.left = rect.top = 0;
		rect.bottom =  rect.right = 0;
		rect.right = 200;
		rect.bottom = 200;
		s_pAxWin->Create(::GetDesktopWindow(), &rect, NULL, WS_CHILD);
		s_pAxWin->CreateControl(L"{8856F961-340A-11D0-A96B-00C04FD705A2}");

	}

	if (s_pAxWin)
	{
		s_pAxWin->QueryControl(IID_IWebBrowser2, (LPVOID FAR*)&pBrowser);
	}
	return pBrowser;
}

static IWebBrowser2* GetRegisteredBrowser()
{
	IWebBrowser2 * pstBrowser = GetBrowser();
	if(pstBrowser != NULL)
	{
		HRESULT hr = 0;
		UINT nLenRegisteredBrowserID = _tcslen(szRegisteredBrowserID);
		BSTR bstrTarget = ::SysAllocStringLen(NULL, nLenRegisteredBrowserID+1);
#ifndef	UNICODE
		MultiByteToWideChar(CP_ACP, MB_USEGLYPHCHARS, szRegisteredBrowserID, (int)nLenRegisteredBrowserID, bstrTarget, (int)nLenRegisteredBrowserID+1);
#else
		_tcscpy_s(bstrTarget, nLenRegisteredBrowserID+1, szRegisteredBrowserID);
#endif
		RH_ITargetFrame2 *pTargetFrame2= NULL;
		pstBrowser->QueryInterface(RH_IID_ITargetFrame2, (void**)&pTargetFrame2);
		if (pTargetFrame2 != NULL)
		{
			if (_tcslen(szRegisteredBrowserID) > 0)
			{
				//IE 5.0+
				IUnknown *pUnk = NULL;
				pTargetFrame2->FindFrame(bstrTarget,0,&pUnk);
				if (pUnk != NULL)
				{
					IWebBrowser2 *pBrowser2 = NULL;
					pUnk->QueryInterface(IID_IWebBrowser2,(void **)&pBrowser2);
					if (pBrowser2 != NULL && pBrowser2 != pstBrowser)
					{
						pstBrowser->Quit();
						pstBrowser->Release();
						pstBrowser = pBrowser2;
					}
					pUnk->Release();
				}
				else
				{
					pstBrowser->Quit();
					pstBrowser->Release();
					pstBrowser=NULL;
				}
			}
			pTargetFrame2->Release();
		}
		::SysFreeString(bstrTarget);
	}

	if(pstBrowser)
		pstBrowser->put_Visible(VARIANT_TRUE);
	return pstBrowser;
}
static BOOL g_bActivateByDlg= FALSE;

class CIEEvents : public IDispatch
{
public:
	// IUnknown
    virtual HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject)
	{
		if (ppvObject == NULL)
			return E_INVALIDARG;

		*ppvObject = NULL;
		if (riid == IID_IDispatch)		
			*ppvObject = static_cast<IDispatch*>(this);
		else if (riid == IID_IUnknown)
			*ppvObject = static_cast<IUnknown*>(this);

		if (*ppvObject != NULL)
		{
			((IUnknown*)(*ppvObject))->AddRef();
			return S_OK;
		}
		return (E_NOINTERFACE);
	}
    
    virtual ULONG STDMETHODCALLTYPE AddRef( void)
	{
		return InterlockedIncrement(&m_lRefCount);
	}
    
    virtual ULONG STDMETHODCALLTYPE Release( void)
	{
		if (InterlockedDecrement(&m_lRefCount) == 0)
		{
			return 0;
			delete this;
		}
		return m_lRefCount;
	}

	// IDispatch
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
        /* [out] */ UINT __RPC_FAR *pctinfo)
	{
		if (pctinfo == NULL)
			return E_INVALIDARG;
		*pctinfo = 0;
		return S_OK;
	}
    
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfo( 
        /* [in] */ UINT iTInfo,
        /* [in] */ LCID lcid,
        /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo)
	{
		return E_NOTIMPL;
	}
    
    virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
        /* [in] */ REFIID riid,
        /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
        /* [in] */ UINT cNames,
        /* [in] */ LCID lcid,
        /* [size_is][out] */ DISPID __RPC_FAR *rgDispId)
	{
		return E_NOTIMPL;
	}
    
private:
	LONG	m_lRefCount;
};


class CHiddenIEEvents : public CIEEvents
{
public:
    virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
        /* [in] */ DISPID dispIdMember,
        /* [in] */ REFIID riid,
        /* [in] */ LCID lcid,
        /* [in] */ WORD wFlags,
        /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
        /* [out] */ VARIANT __RPC_FAR *pVarResult,
        /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
        /* [out] */ UINT __RPC_FAR *puArgErr)
	{
		switch (dispIdMember)
		{
			case DISPID_NEWWINDOW2:
				if (!g_bActivateByDlg && pDispParams->cArgs == 2)
				{
					if (pDispParams->rgvarg[1].vt == (VT_BYREF | VT_DISPATCH))
					{
						IDispatch *pBrowserDisp = NULL;
						IWebBrowser2 *pBrowser=GetRegisteredBrowser();
						if(NULL != pBrowser)
						{
							pBrowser->QueryInterface(IID_IDispatch, (void**)&pBrowserDisp);	
							*(pDispParams->rgvarg[1].ppdispVal) = pBrowserDisp;
						}
						else if ((int)s_hParent != -1)
						{
							pBrowser = GetTopicBrowser();
							pBrowser->QueryInterface(IID_IDispatch, (void**)&pBrowserDisp);
							*(pDispParams->rgvarg[1].ppdispVal) = pBrowserDisp;
						}
					}
				}
				else if ((int)s_hParent != -1)
				{
					IDispatch *pBrowserDisp = NULL;
					IWebBrowser2 *pBrowser= GetTopicBrowser();
					pBrowser->QueryInterface(IID_IDispatch, (void**)&pBrowserDisp);	
					*(pDispParams->rgvarg[1].ppdispVal) = pBrowserDisp;
				}
				break;
			case DISPID_NAVIGATECOMPLETE2:
				if (pDispParams)
				{
					if (pDispParams->cArgs == 2)
					{
						if (pDispParams->rgvarg[0].vt == (VT_VARIANT | VT_BYREF))
						{
							VARIANT *pValURL = pDispParams->rgvarg[0].pvarVal;
							if (pValURL->vt == VT_BSTR)
							{
								int nLength = SysStringLen(pValURL->bstrVal);
								_TCHAR *pszURL = new TCHAR[nLength + 1];
								pszURL[nLength] = _T('\0');
#ifndef	UNICODE
	WideCharToMultiByte(CP_ACP, 0, pValURL->bstrVal, nLength, pszURL, nLength, NULL, NULL);
#else
	_tcscpy_s(pszURL, nLength + 1, pValURL->bstrVal);
#endif
								delete[] pszURL;
							}
						}
					}
				}
				break;
			default:
				break;
		}
		return S_OK;
	}
};


class CTopicIEEvents : public CIEEvents
{
public:
	CTopicIEEvents():
		m_nLeft(0),
		m_nTop(0),
		m_nWidth(-1),
		m_nHeight(0)
	{
	}

    virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
        /* [in] */ DISPID dispIdMember,
        /* [in] */ REFIID riid,
        /* [in] */ LCID lcid,
        /* [in] */ WORD wFlags,
        /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
        /* [out] */ VARIANT __RPC_FAR *pVarResult,
        /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
        /* [out] */ UINT __RPC_FAR *puArgErr)
	{
		switch (dispIdMember)
		{
			case 264: // DISPID_WINDOWSETLEFT    
			case 265: // DISPID_WINDOWSETTOP
			case 266: // DISPID_WINDOWSETWIDTH
			case 267: // DISPID_WINDOWSETHEIGHT
				if (pDispParams)
				{
					if (pDispParams->cArgs == 1)
					{
						if (pDispParams->rgvarg[0].vt == (VT_I4))
						{
							int nValue = pDispParams->rgvarg[0].intVal;
							switch (dispIdMember)
							{
								case 264: // DISPID_WINDOWSETLEFT  
									m_nLeft = nValue;
									break;
								case 265: // DISPID_WINDOWSETTOP
									m_nTop = nValue;
									break;
								case 266: // DISPID_WINDOWSETWIDTH
									m_nWidth = nValue;
									break;
								case 267: // DISPID_WINDOWSETHEIGHT
									m_nHeight = nValue;
									break;
							}
						}
					}
				}
				break;
			case 259: // DISPID_DOCUMENTCOMPLETE
				if (s_pAxTopicWin)
				{
					if (m_nWidth != 0)
					{
						if (m_nWidth > 0)
						{
							RECT rect;
							rect.left = m_nLeft;
							rect.top = m_nTop;
							rect.bottom = m_nTop + m_nHeight;
							rect.right = m_nLeft + m_nWidth;

							AdjustWindowRectEx(&rect, s_pAxTopicWin->GetWindowLong(GWL_STYLE), NULL, 
								s_pAxTopicWin->GetWindowLong(GWL_EXSTYLE));

							OffsetRect(&rect, (rect.left < 0)? -(rect.left) : 0, (rect.top < 0) ? -(rect.top) : 0);

							s_pAxTopicWin->MoveWindow(&rect);
							s_pAxTopicWin->ShowWindow(SW_SHOW);
							m_nWidth = 0;
						}
						else
						{
							int nFullScreenX = GetSystemMetrics(SM_CXFULLSCREEN);
							int nFullScreenY = GetSystemMetrics(SM_CYFULLSCREEN);
							s_pAxTopicWin->MoveWindow(nFullScreenX/2, 0, nFullScreenX/2, nFullScreenY/2);
							s_pAxTopicWin->ShowWindow(SW_SHOW);
						}
					}
				}
				break;
			case 105: // DISPID_COMMANDSTATECHANGE:
				{
					if (s_pAxTopicWin && pDispParams)
					{
						if (pDispParams->cArgs == 2)
						{
							if (pDispParams->rgvarg[1].vt == (VT_I4) && pDispParams->rgvarg[0].vt == (VT_BOOL))
							{
								VARIANT_BOOL bEnable = pDispParams->rgvarg[0].boolVal;
								int nCommand = pDispParams->rgvarg[1].intVal;

								HWND hToolbar = s_pAxTopicWin->GetDlgItem(ID_TOOLBAR);
								if (hToolbar)
								{
									switch (nCommand)
									{
									case 1: // CSC_NAVIGATEFORWARD:
										SendMessage(hToolbar, TB_ENABLEBUTTON, ID_FORWARD, MAKELONG(bEnable, 0));

										break;
									case 2: // CSC_NAVIGATEBACK:
										SendMessage(hToolbar, TB_ENABLEBUTTON, ID_BACK, MAKELONG(bEnable, 0));
										break;
									}
								}
							}

						}
					}
				}
				break;
			default:
				break;
		}
		return S_OK;
	}
private:
	int m_nLeft;
	int m_nTop;
	int m_nWidth;
	int m_nHeight;
};

static CHiddenIEEvents gHiddenIeEvents;
static CTopicIEEvents gTopicIeEvents;

void AddIeEventListener(IWebBrowser2* pstBrowser, IDispatch *pDispatch)
{
	if (pstBrowser)
	{
		// this is to disable those popup block tools, (like google bar, msn bar)
		// this method won't work for xp sp2. :(
		// I am going to add a register key dynamiclly.
		// HKEY_CURRENT_USER\Software \Microsoft\Internet Explorer\New Windows\Allow
		IConnectionPointContainer *pConnectionPointContainer = NULL;
		IConnectionPoint *pConnectionPoint = NULL;
		HRESULT hr = pstBrowser->QueryInterface(IID_IConnectionPointContainer, (void**) &pConnectionPointContainer);
		if (hr == S_OK && pConnectionPointContainer)
		{

			hr = pConnectionPointContainer->FindConnectionPoint(DIID_DWebBrowserEvents2, &pConnectionPoint);
			if (hr == S_OK && pConnectionPoint)
			{
				IEnumConnections *pEnumConnections = NULL;

				hr = pConnectionPoint->EnumConnections(&pEnumConnections);

				if (hr == S_OK && pEnumConnections)
				{
					do
					{
						CONNECTDATA ConnectData;
						ULONG uFetched = 0;
						hr = pEnumConnections->Next(1, &ConnectData, &uFetched);
						if (hr == S_OK && uFetched == 1)
						{
							pConnectionPoint->Unadvise(ConnectData.dwCookie);
						}
						else
							break;
					} while (TRUE);

					IUnknown *pUnknown = NULL;

					ULONG dwCookie = 0;

					if (S_OK == pDispatch->QueryInterface(IID_IUnknown, (void**)&pUnknown))
						pConnectionPoint->Advise(pUnknown, &dwCookie);

					pEnumConnections->Release();
				}
				pConnectionPoint->Release();
			}
			pConnectionPointContainer->Release();
		}
	}
}

static WNDPROC  oldTopicWndProc = NULL;

static void MoveIEWindow(HWND hWnd)
{
	RECT  rc, rcToolbar;
	int   cx, cy;

	GetClientRect(hWnd, &rc);

	HWND hToolbar = GetDlgItem(hWnd, ID_TOOLBAR);

	if (hToolbar)
		GetWindowRect(hToolbar, &rcToolbar);
	else
		rcToolbar.left = rcToolbar.right = rcToolbar.bottom = rcToolbar.top = 0;


	cx = rc.right - rc.left;
	cy = rcToolbar.bottom - rcToolbar.top;

	if (hToolbar)
		MoveWindow(hToolbar, 0, 0, cx, cy, FALSE);

	HWND hChildWnd = ::GetWindow(hWnd, GW_CHILD);
	MoveWindow(hChildWnd, 0, cy, cx, rc.bottom - cy, FALSE);
}

LRESULT TopicWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_SIZE:
		MoveIEWindow(hWnd);
		return -1;
	case WM_COMMAND:
		{
			IWebBrowser2* pBrowser = GetTopicBrowser();
			switch (LOWORD(wParam))
			{
			case ID_BACK:
				pBrowser->GoBack();
				break;
			case ID_FORWARD:
				pBrowser->GoForward();
				break;
			case ID_PRINT:
				{
					IDispatch *pDoc = NULL;
					HRESULT hr = pBrowser->get_Document(&pDoc);
					if (hr == S_OK && pDoc)
					{
						IHTMLDocument2 *pHtmlDoc = NULL;
						hr = pDoc->QueryInterface(IID_IHTMLDocument2, (void**)&pHtmlDoc);
						if (hr == S_OK && pHtmlDoc)
						{
							IHTMLWindow2 *pHtmlWindow2 = NULL;

							hr = pHtmlDoc->get_parentWindow(&pHtmlWindow2);
							if (hr == S_OK && pHtmlWindow2)
							{
								RH_IHTMLWindow3 *pHtmlWindow3 = NULL;
								hr = pHtmlWindow2->QueryInterface(RH_IID_IHTMLWindow3, (void**) &pHtmlWindow3);
								if (hr == S_OK && pHtmlWindow3)
								{
									pHtmlWindow3->print();
									pHtmlWindow3->Release();

								}
								pHtmlWindow2->Release();

							}
							pHtmlDoc->Release();
						}
						pDoc->Release();
					}
				}

			}
		}
		break;
	case 0x0319: // WM_APPCOMMAND
		{
			IWebBrowser2* pBrowser = GetTopicBrowser();
			int ncmd = ((short)(HIWORD(lParam) & ~0xF000));
			switch (ncmd)
			{
			case 1: // APPCOMMAND_BROWSER_BACKWARD
				pBrowser->GoBack();
				break;
			case 2: // APPCOMMAND_BROWSER_FORWARD
				pBrowser->GoForward();
				break;
			}
		}
		break;
	}

	if (oldTopicWndProc)
		return CallWindowProc(oldTopicWndProc, hWnd, uMsg, wParam, lParam);
	else
		return -1;
}



static HWND BuildToolBar(HWND hwndParent)
{
	HWND hwndTB = CreateWindowEx(0, TOOLBARCLASSNAME, (LPTSTR)NULL,
					WS_CHILD|TBSTYLE_LIST|CCS_ADJUSTABLE, 
					0, 0, 0, 0,
					hwndParent,
					(HMENU)ID_TOOLBAR,
					NULL,
					NULL);

	SendMessage(hwndTB, TB_BUTTONSTRUCTSIZE, (WPARAM) sizeof(TBBUTTON), 0); 

	int iBack, iForward, iPrint;

	_TCHAR szBuf[16];
	_tcscpy_s(szBuf, 16, _T("Back"));
	szBuf[_tcslen(szBuf) + 1] = 0;  //Double-null terminate. 
	iBack = SendMessage(hwndTB, TB_ADDSTRING, 0, (LPARAM) (LPTSTR)szBuf); 


	_tcscpy_s(szBuf, 16, _T("Forward"));
	//Save room for second null terminator. 
	szBuf[_tcslen(szBuf) + 1] = 0;  //Double-null terminate. 
	iForward = SendMessage(hwndTB, TB_ADDSTRING, (WPARAM) 0, 
	(LPARAM) (LPTSTR) szBuf); 

	_tcscpy_s(szBuf, 16, _T("Print"));
	//Save room for second null terminator.
	szBuf[_tcslen(szBuf) + 1] = 0;  //Double-null terminate.  
	iPrint = SendMessage(hwndTB, TB_ADDSTRING, (WPARAM) 0, 
	(LPARAM) (LPTSTR) szBuf); 


	SendMessage(hwndTB, TB_LOADIMAGES, (WPARAM)(INT)IDB_HIST_SMALL_COLOR, (LPARAM)(HINSTANCE)HINST_COMMCTRL);

	SendMessage(hwndTB, TB_LOADIMAGES, (WPARAM)(INT)IDB_STD_SMALL_COLOR, (LPARAM)(HINSTANCE)HINST_COMMCTRL);

	TBBUTTON tbb[3]; 

	// Fill the TBBUTTON array with button information, and add the 
	// buttons to the toolbar. The buttons on this toolbar have text 
	// but do not have bitmap images. 
	tbb[0].iBitmap = HIST_BACK ; 
	tbb[0].idCommand = ID_BACK; 
	tbb[0].fsState = TBSTATE_ENABLED; 
	tbb[0].fsStyle = TBSTYLE_BUTTON; 
	tbb[0].dwData = 0; 
	tbb[0].iString = iBack;

	tbb[1].iBitmap = HIST_FORWARD; 
	tbb[1].idCommand = ID_FORWARD; 
	tbb[1].fsState = TBSTATE_ENABLED; 
	tbb[1].fsStyle = TBSTYLE_BUTTON; 
	tbb[1].dwData = 0; 
	tbb[1].iString = iForward; 

	tbb[2].iBitmap = STD_PRINT; 
	tbb[2].idCommand = ID_PRINT; 
	tbb[2].fsState = TBSTATE_ENABLED; 
	tbb[2].fsStyle = TBSTYLE_BUTTON; 
	tbb[2].dwData = 0; 
	tbb[2].iString = iPrint; 

	SendMessage(hwndTB, TB_ADDBUTTONS, (WPARAM) 3, 
	(LPARAM) (LPTBBUTTON) tbb); 

	int nCount = SendMessage(hwndTB, TB_BUTTONCOUNT, 0, 0);

	SendMessage(hwndTB, TB_AUTOSIZE, 0, 0); 

	ShowWindow(hwndTB, SW_SHOW); 

	MoveIEWindow(hwndParent);

	return hwndTB;
}



IWebBrowser2* GetTopicBrowser() 
{
	IWebBrowser2 *pBrowser = NULL;
	// If the caller already initialize COM, please comment out the next 5 lines.
	if (!gbCoInited)
	{
		::CoInitialize(NULL);
		gbCoInited=1;
	}

	if (!s_pAxTopicWin || !s_pAxTopicWin->IsWindow())
	{
		delete s_pAxTopicWin;
		AtlAxWinInit();
		s_pAxTopicWin = new CAxWindow;
		RECT rect;
		rect.left = rect.top = 0;
		rect.bottom =  rect.right = 200;

		s_pAxTopicWin->Create(::GetDesktopWindow(), &rect, NULL, WS_POPUPWINDOW|WS_CAPTION|WS_THICKFRAME);

		s_pAxTopicWin->CreateControl(L"{8856F961-340A-11D0-A96B-00C04FD705A2}");

		oldTopicWndProc = (WNDPROC)s_pAxTopicWin->GetWindowLong(GWL_WNDPROC);

		s_pAxTopicWin->SetWindowLong(GWL_WNDPROC, (LONG)TopicWndProc);

//		BuildToolBar(s_pAxTopicWin->m_hWnd);
	}

	if (s_pAxTopicWin)
	{
		HWND hClient = s_hParent;

		if (hClient == NULL )
			hClient = GetForegroundWindow();

		if (hClient && hClient != s_pAxTopicWin->m_hWnd)
		{
			HICON hIcon = (HICON)::SendMessage(hClient, WM_GETICON, ICON_SMALL, 0);

			if( hIcon == NULL )	
				hIcon = (HICON)::SendMessage(hClient, WM_GETICON, ICON_BIG, 0 );

			if(hIcon == NULL) 
				hIcon = (HICON)::GetClassLong(hClient, GCL_HICONSM );

			if (hIcon == NULL)
				hIcon = ::LoadIcon(NULL, IDI_QUESTION);

			if (hIcon)
				s_pAxTopicWin->SetIcon(hIcon, FALSE);

			unsigned int uTitleLength = MAX_PATH + _tcslen(szHelpTitle) + 1;
			LPTSTR pszTitle = new _TCHAR [uTitleLength];

			pszTitle[0] = _T('\0');

			::GetWindowText(hClient, pszTitle, MAX_PATH);

			if (_tcslen(pszTitle) > 0)
			{
				LPTSTR pszSubTitle =  _tcschr(pszTitle, _T('-'));
				if (pszSubTitle)
				{
					pszSubTitle[0] = _T('\0');
				}

				_tcscat_s(pszTitle, uTitleLength, szHelpTitle);
				s_pAxTopicWin->SetWindowText(pszTitle);
			}

			delete[] pszTitle;
		}

		s_pAxTopicWin->QueryControl(IID_IWebBrowser2, (LPVOID FAR*)&pBrowser);
	}

	AddIeEventListener(pBrowser, &gTopicIeEvents);

	if(!s_pOleInPlaceActiveObject)
		pBrowser->QueryInterface(IID_IOleInPlaceActiveObject,(LPVOID *)&s_pOleInPlaceActiveObject);  	
	return pBrowser;
}

#endif

static int FH_UpdateQS(const _TCHAR * pszUpdateList, const _TCHAR *pszHelpURL, const _TCHAR *pszQuick, const _TCHAR *pszOptions)
{
	int nCount = 0;
	int nUpper = 0;
	int nRet = 1;
	bool bDisplayStatus = false;

#ifdef _WIN32
	if (s_pstBrowser == NULL)
		 s_pstBrowser = GetBrowser();
	if (s_pstBrowser!= NULL)
	{
		bDisplayStatus = true;
	}
#endif

	if (bDisplayStatus)
	{
		// Display the status Swf
		TCHAR* pszHelpFile = new _TCHAR[MAX_RH_URL_BUFLEN];
		_tcsnset_s(pszHelpFile, MAX_RH_URL_BUFLEN, _T('\0'), MAX_RH_URL_BUFLEN);
		_tcscpy_s(pszHelpFile, MAX_RH_URL_BUFLEN, pszQuick);
		_tcscat_s(pszHelpFile, MAX_RH_URL_BUFLEN, _T("wf_startqs.htm#osw=true"));
		_tcscat_s(pszHelpFile, MAX_RH_URL_BUFLEN, pszOptions);
		ShowHelpTopic_Win32_IE(pszHelpFile);
		delete[] pszHelpFile;

		// Get the total number of files that need to be downloaded
		const _TCHAR* pszTemp = _tcschr(pszUpdateList,_T('|'));
		while (pszTemp != NULL)
		{
			nUpper++;
			if (_tcslen(pszTemp)>0)
				pszTemp = _tcschr(pszTemp+1,_T('|'));
			else
				pszTemp = NULL;
		}
	}

	// Get the server name
	UINT nLenHelpURL = _tcslen(pszHelpURL);
	_TCHAR * pHostName  = new _TCHAR[nLenHelpURL + 1];
	_tcscpy_s(pHostName, nLenHelpURL + 1, pszHelpURL);

	LPTSTR pBeginPos = _tcsstr(pHostName, _T("//"));
	if (pBeginPos)
	{
		LPTSTR pEndPos = _tcsstr(pBeginPos+2, _T("/"));
		if (pEndPos)
		{
			pEndPos[0] = '\0';
			pHostName[_tcslen(pHostName)-1] = '\0';
		}
		else
			pHostName[0] = '\0';
	}
	else
		pHostName[0] = '\0';

	UINT nLenUpdateList = _tcslen(pszUpdateList);
	_TCHAR* pszURLList = new _TCHAR[nLenUpdateList+1];
	_tcscpy_s(pszURLList, nLenUpdateList+1, pszUpdateList);
	pszURLList[nLenUpdateList] = _T('\0');
	_TCHAR* pszStart = pszURLList;

	while (pszURLList != NULL)
	{
		_TCHAR* pszTemp = _tcsstr(pszURLList, _T("|"));
		if (pszTemp != NULL)
		{
			// Get the current item
			_TCHAR* pszItem = new _TCHAR[(pszTemp - pszURLList)+1];
			_tcsncpy_s(pszItem, (pszTemp - pszURLList)+1, pszURLList, pszTemp - pszURLList);
			pszItem[pszTemp - pszURLList] = _T('\0');
			
			_TCHAR* pszFile = new _TCHAR[MAX_PATH];
			_TCHAR* pszExt = new _TCHAR[MAX_PATH];
			_tsplitpath_s(pszItem, NULL, 0, NULL, 0, pszFile, MAX_PATH, pszExt, MAX_PATH);
			_tcscat_s(pszFile, MAX_PATH, pszExt);
			delete[] pszExt;

			unsigned int uDestLen = _tcslen(pszQuick)+ _tcslen(pszFile) + 1;
			_TCHAR* pszDest = new _TCHAR[uDestLen];
			_tcscpy_s(pszDest, uDestLen, pszQuick);
			_tcscat_s(pszDest, uDestLen, pszFile);
			pszDest[_tcslen(pszQuick)+ _tcslen(pszFile)] = _T('\0');
			delete[] pszFile;

			unsigned int  uTargetLen = _tcslen(pHostName)+ _tcslen(pszItem) + 1;
			_TCHAR* pszTarget = new _TCHAR[uTargetLen];
 			_tcscpy_s(pszTarget, uTargetLen, pHostName);
			_tcscat_s(pszTarget, uTargetLen, pszItem);
			pszTarget[_tcslen(pHostName)+ _tcslen(pszItem)] = _T('\0');

			
			if (URLDownloadToFile(NULL,pszTarget,pszDest, 0, NULL) != S_OK)
			{
				nRet = 0;
			}
			else if (bDisplayStatus)
			{
				nCount++;
				_TCHAR* pszHelpFile = new _TCHAR[MAX_RH_URL_BUFLEN];
				_TCHAR* pszParams = new _TCHAR[MAX_RH_URL_BUFLEN];
				_tcsnset_s(pszHelpFile, MAX_RH_URL_BUFLEN, _T('\0'), MAX_RH_URL_BUFLEN);
				_tcscpy_s(pszHelpFile, MAX_RH_URL_BUFLEN, pszQuick);
				_tcscat_s(pszHelpFile, MAX_RH_URL_BUFLEN, _T("wf_updatestatus.htm#"));

				_stprintf_s(pszParams, MAX_RH_URL_BUFLEN, FH_UPDATE_INFO, 5, nCount, nUpper);
				_tcscat_s(pszHelpFile,MAX_RH_URL_BUFLEN, pszParams);

				ShowHelpTopic_Win32_IE(pszHelpFile);
				delete[] pszHelpFile;
				delete[] pszParams;
			}

			delete[] pszTarget;
			delete[] pszDest;
			delete[] pszItem;
			pszTemp++;
		}
		pszURLList = pszTemp;
	}
	delete[] pszStart;
	delete[] pHostName;
	
	return nRet;
}

int WH_ShowFlashHelp_QS(HWND hParent, const _TCHAR * pszHelpURL, const _TCHAR *pszQuick, const _TCHAR *pszWnd, unsigned int uCommand, DWORD dwData, int nUpdate)
{
	int nRet=0;
	BOOL bUseQuickStart = false;
	_TCHAR* pszUpdate;

	// Strip the asp page name and get the project name
	UINT nLenHelpURL = _tcslen(pszHelpURL);
	_TCHAR* pszSvrURL = new _TCHAR[nLenHelpURL+1];
	_tcscpy_s(pszSvrURL, nLenHelpURL+1, pszHelpURL);

	LPTSTR pAPIPos = _tcsstr(pszSvrURL, _T("roboapi.asp"));
	LPTSTR pProjectName = NULL;
	if (pAPIPos)
	{
		pProjectName = _tcsstr(pAPIPos, _T("?project="));
		if (pProjectName)
		{
			pProjectName += 9;
		}
		pAPIPos[0] = '\0';
	}

	// Get the update string
	pszUpdate = FH_GetUpdateString(pszQuick);
	
	if (pszUpdate != NULL && _tcslen(pszUpdate) != 0 )
	{
		_TCHAR* pszHeader;
		_TCHAR* pszPostData;

		// Build the post data
		DWORD dwWndLen = 0;
		DWORD dwCtxLen = 0;
		DWORD dwPrjLen = 0;

		_TCHAR pszCtxId[MAX_PATH];
		if (uCommand == HH_HELP_CONTEXT && dwData != NULL)
		{
			_itot_s(dwData,pszCtxId,10);
			dwCtxLen = _tcslen(pszCtxId);
		}

		if (pszWnd)
		{
			dwWndLen = _tcslen(pszWnd);
		}

		if (pProjectName)
		{
			dwPrjLen = _tcslen(pProjectName);
		}

		DWORD dwSize = _tcslen(FH_POST_PROJECT) + dwPrjLen +				// Project
					   _tcslen(FH_POST_WND) + dwWndLen +					// Window
					   _tcslen(FH_POST_CTX) + dwCtxLen +					// Context ID
					   _tcslen(FH_POST_UPDATE) + _tcslen(pszUpdate) + 5;	// Update String

		pszPostData = new _TCHAR[dwSize];
		_tcsnset_s(pszPostData, dwSize, _T('\0'), dwSize);

		_tcscat_s(pszPostData, dwSize, FH_POST_PROJECT);
		if (pProjectName)
		{
			_tcscat_s(pszPostData, dwSize, pProjectName);
		}

		_tcscat_s(pszPostData,  dwSize,_T("&"));
		_tcscat_s(pszPostData,  dwSize,FH_POST_WND);
		if (pszWnd)
		{
			_tcscat_s(pszPostData,  dwSize,pszWnd);
		}

		_tcscat_s(pszPostData, dwSize, _T("&"));
		_tcscat_s(pszPostData, dwSize, FH_POST_CTX);

		if (pszCtxId && uCommand == HH_HELP_CONTEXT)
		{
			_tcscat_s(pszPostData, dwSize, pszCtxId);
		}

		_tcscat_s(pszPostData,  dwSize,_T("&"));
		_tcscat_s(pszPostData,  dwSize,FH_POST_UPDATE);
		_tcscat_s(pszPostData,  dwSize,pszUpdate); 
		_tcscat_s(pszPostData,  dwSize,_T("&"));

		// Build the header
		_TCHAR pszSize[MAX_PATH];
		_itot_s(_tcslen(pszPostData),pszSize,10);
		DWORD dwHeaderLen = _tcslen(FH_POST_HEADER) + _tcslen(pszSize);
		pszHeader = new _TCHAR[dwHeaderLen];
		_stprintf_s(pszHeader, dwHeaderLen, FH_POST_HEADER, pszSize);

		// Post the data to the server
		_TCHAR* pszServerData = FH_PostUpdateData(pszSvrURL, pszHeader, pszPostData);
		
		delete[] pszPostData;
		delete[] pszHeader;

		FH_SvrInfo* pSvrInfo = NULL;

		if (pszServerData)
		{
			bUseQuickStart = true;
			// Parse the server data
			pSvrInfo = FH_ParseSvrInfo(pszServerData);

			if (pszWnd == NULL)
			{
				BOOL bSet = false;
				_TCHAR* pszDefBtn = new _TCHAR[MAX_PATH];
				switch (uCommand)
				{
					case HH_DISPLAY_INDEX:
						_tcscpy_s(pszDefBtn, MAX_PATH,_T("ndx"));
						bSet = true;
						break;
					case HH_DISPLAY_SEARCH:
						bSet = true;
						_tcscpy_s(pszDefBtn, MAX_PATH,_T("nls"));
						break;
					case HH_DISPLAY_TOC:
						bSet = true;
						_tcscpy_s(pszDefBtn, MAX_PATH,_T("toc"));
						break;
				}
				if (bSet)
				{
					if (pSvrInfo->m_pszDefault)
						delete[] pSvrInfo->m_pszDefault;
					pSvrInfo->m_pszDefault = pszDefBtn;
				}
				else
				{
					delete[] pszDefBtn;
				}
			}
			
			if (pSvrInfo->m_pszUpdate !=NULL)
			{
				if (nUpdate ==1 )
				{
					// Update the outdated files
					_TCHAR* pszOptions = pSvrInfo->GetFHOptionStr();
					if (FH_UpdateQS(pSvrInfo->m_pszUpdate, pszSvrURL, pszQuick, pszOptions) == 0)
					{
						bUseQuickStart = false;
					}
					delete[] pszOptions;
				}
				else
				{
					bUseQuickStart = false;
				}
			}
				
			delete[] pszServerData;
		}

		// Display the help system
		if (bUseQuickStart)
		{
			_TCHAR* pszQSPath = new _TCHAR[MAX_RH_URL_BUFLEN];
			// Build the context string
			_tcscpy_s(pszQSPath, MAX_RH_URL_BUFLEN, pszQuick);
			_tcscat_s(pszQSPath, MAX_RH_URL_BUFLEN, FH_QUICK_START);
					
			// Add the server location
			_TCHAR* pszSvrPath = new _TCHAR[MAX_RH_URL_BUFLEN];
			_tcscpy_s(pszSvrPath, MAX_RH_URL_BUFLEN, pszSvrURL);
			FH_URLEncode(pszSvrPath, MAX_RH_URL_BUFLEN);
			_tcscat_s(pszQSPath, MAX_RH_URL_BUFLEN, _T("#svr="));
			_tcscat_s(pszQSPath, MAX_RH_URL_BUFLEN, pszSvrPath);

			if (pProjectName)
			{
				_tcscat_s(pszQSPath, MAX_RH_URL_BUFLEN, _T(">>prj="));
				_tcscat_s(pszQSPath, MAX_RH_URL_BUFLEN, pProjectName);
			}

			delete[] pszSvrPath;

			_TCHAR* pOpt = pSvrInfo->GetFHOptionStr();

			
			_tcscat_s(pszQSPath, MAX_RH_URL_BUFLEN, pOpt);

			nRet = ShowWebHelp(hParent, pszQSPath);

			delete[] pszQSPath;
			delete[] pOpt;
		}

		if (pSvrInfo)
			delete pSvrInfo;


		delete[] pszUpdate;
	}

	delete[] pszSvrURL;
	
	return nRet;
}

int WH_ShowWebHelp_Server(HWND hParent, const _TCHAR * pszHelpURL, const _TCHAR *pszWnd, unsigned int uCommand, DWORD dwData)
{
	int nRet=0;
	_TCHAR szParam[PARAM_LEN];
	int nCmd=0;
	switch (uCommand)
	{
	case HH_HELP_CONTEXT:
		{
			int nId = dwData;
			const _TCHAR *pPos = _tcschr(pszHelpURL, _T('?'));
			if (pPos != NULL)
				_stprintf_s(szParam, PARAM_LEN, _T("&ctxid=%d"), nId);
			else
				_stprintf_s(szParam, PARAM_LEN, _T("?ctxid=%d"), nId);
			nCmd = 1;
		}
		break;
	case HH_DISPLAY_INDEX:
	case HH_DISPLAY_SEARCH:
	case HH_DISPLAY_TOC:
	case HH_DISPLAY_TOPIC:
		{
			const _TCHAR *pPos = _tcschr(pszHelpURL, _T('?'));
			if (pPos != NULL)
				_tcscpy_s(szParam, PARAM_LEN, _T("&ctxid=0"));
			else
				_tcscpy_s(szParam, PARAM_LEN, _T("?ctxid=0"));
            nCmd = 1;
		}
		break;
	}
	if (nCmd)
	{
		unsigned uWndLength = 0;
		if (pszWnd)
			uWndLength = (unsigned)_tcslen(pszWnd) + 1;

		unsigned int uURLLength = _tcslen(pszHelpURL) + _tcslen(szParam) + uWndLength + 1;
		_TCHAR *pszURL=new _TCHAR[uURLLength];
		_tcscpy_s(pszURL, uURLLength, pszHelpURL);
		_tcscat_s(pszURL, uURLLength, szParam);
		if (pszWnd)
		{
			_tcscat_s(pszURL, uURLLength, _T(">"));
			_tcscat_s(pszURL, uURLLength, pszWnd);
		}
		nRet = ShowWebHelp(hParent, pszURL);
		delete[] pszURL;
	}
	return nRet;
}

unsigned int GetCommandForHelpSource(const _TCHAR *pszHelpSource, DWORD dwData)
{
	if (IsWinHelp(pszHelpSource))
		return HELP_CONTEXT;

	if (IsHtmlHelp(pszHelpSource))
	{
		// if there is a map number, it's a context-sensitive help call
		if (dwData > 0)
			return HH_HELP_CONTEXT;
		// otherwise, it's a call to just display the help or a specific file in the chm
		return HH_DISPLAY_TOPIC;
	}

	// this must be a WebHelp system
	if (dwData > 0)
		return HH_HELP_CONTEXT;
	return HH_DISPLAY_TOPIC;
	
	return 0;
}


int IsHtmlHelp(const _TCHAR * pszHelpSource)
{
	const _TCHAR *pDot = _tcsrchr(pszHelpSource,'.');
	if ((pDot != 0) &&
		((pszHelpSource + _tcslen(pszHelpSource) - pDot) >= 4) &&
		(_tcsnicmp(pDot,_T(".chm"), 4) == 0))
	{
		return 1;
	}
	return 0;
}

int IsWinHelp(const _TCHAR * pszHelpSource)
{
	const _TCHAR *pDot = _tcsrchr(pszHelpSource,'.');
	if ((pDot != 0) &&
		((pszHelpSource + _tcslen(pszHelpSource) - pDot) >= 4) &&
		(_tcsnicmp(pDot,_T(".hlp"), 4) == 0))
	{
		return 1;
	}
	return 0;
}

int IsWebAddress(const _TCHAR * pszHelpSource)
{
	if ((_tcsnicmp(pszHelpSource, _T("http://"), 7) == 0) || (_tcsnicmp(pszHelpSource, _T("https://"), 8) == 0))
		return 1;
	return 0;
}


/**********************************************************************************************************
*************************************** Internal routines *************************************************
***********************************************************************************************************/
/* Is Server based or not (WebHelp Enterprise/RHI or WebHelp) */
int IsServerBased(const _TCHAR *a_pszUrlToHelpSet)
{
	int nRet = 1;
	if (_tcslen(a_pszUrlToHelpSet) > 0)
	{
		const _TCHAR *pDot = _tcsrchr(a_pszUrlToHelpSet,'.');
		if ((pDot != 0) &&
			((a_pszUrlToHelpSet + _tcslen(a_pszUrlToHelpSet) - pDot) >= 4) &&
			(_tcsnicmp(pDot,_T(".htm"), 4) == 0))
		{
			nRet = 0;
		}
	}
	return nRet;
}


#ifdef _WIN32
/* Show Help topic in Win32 platform */
int ShowHelpTopic_Win32(const _TCHAR *a_pszUrl)
{
	int nRet=0;
	if (s_pstBrowser == NULL)
		 s_pstBrowser = GetBrowser();
	if (s_pstBrowser!= NULL)
	{
		nRet=ShowHelpTopic_Win32_IE(a_pszUrl);
	}
	else
	{
		nRet=ShowHelpTopic_Win32_NonIE(a_pszUrl);
	}
	return nRet;
}

static BOOL ActivateByDialog()
{
	_TCHAR strClassName[60]; 
	HWND hWnd = ::GetForegroundWindow();
	::GetClassName (hWnd, strClassName, sizeof(strClassName) / sizeof(strClassName[0])); 

	if ( _tcscmp(strClassName, _T("#32770"/*Dialog*/)) == 0)
		return TRUE;
	return FALSE;
}

static int ShowHelpTopic_Win32_IE(const _TCHAR *a_pszUrl)
{
	HRESULT hr = 0;
	UINT nLenTargetID = _tcslen(szTargetID);
	BSTR bstrTarget = ::SysAllocStringLen(NULL, nLenTargetID+1);
#ifndef	UNICODE
	MultiByteToWideChar(CP_ACP, MB_USEGLYPHCHARS, szTargetID, (int)nLenTargetID, bstrTarget, (int)nLenTargetID+1);
#else
	_tcscpy_s(bstrTarget, nLenTargetID+1, szTargetID);
#endif


	if (s_pstBrowser == NULL)
		 s_pstBrowser = GetBrowser();
	if (!s_pstBrowser) return 0;

	const _TCHAR *pszUrl = a_pszUrl;
	_TCHAR *pszNewUrl = NULL;
	BOOL bWebAddress  = FALSE;

	if (IsWebAddress(a_pszUrl))
	{
		if (IsServerBased(a_pszUrl))
		{
			const _TCHAR *pPos = _tcschr(a_pszUrl, '?');
			unsigned int uNewURLLength = _tcslen(a_pszUrl) + 30;
			pszNewUrl = new _TCHAR[uNewURLLength];
			_tcscpy_s(pszNewUrl, uNewURLLength, a_pszUrl);
			if (pPos != NULL)
				_tcscat_s(pszNewUrl,uNewURLLength, _T("&cmd=newwnd&rtype=iefrm"));
			else
				_tcscat_s(pszNewUrl,uNewURLLength, _T("?cmd=newwnd&rtype=iefrm"));

			pszUrl = pszNewUrl;
		}
		bWebAddress = TRUE;
	}

	VARIANT vFlags = {0};
	V_VT(&vFlags) = VT_I4;
	V_I4(&vFlags) = 0;

	VARIANT vPostData = {0};
	VARIANT vTargetFrameName = {0};

	// Put data into safe array.
	LPSAFEARRAY psa = SafeArrayCreateVector(VT_UI1, 0, 0);

	LPSTR pPostData;
	hr=SafeArrayAccessData(psa, (LPVOID*)&pPostData);
	hr = SafeArrayUnaccessData(psa);

	// Package the SafeArray into a VARIANT.
	V_VT(&vPostData) = VT_ARRAY | VT_UI1;
	V_ARRAY(&vPostData) = psa;         
	
	// Get Headers.
	VARIANT vHeaders = {0};
	V_VT(&vHeaders) = VT_BSTR;         

	// Specify a binary Content-Type.
	V_BSTR(&vHeaders) = SysAllocString(
		L"Content-Type: application/octet-stream\r\n"
		L"Content-Encoding: html/text\r\n");

	//target name
	V_VT(&vTargetFrameName) = VT_BSTR;
	V_BSTR(&vTargetFrameName) = bstrTarget; // want to set framename? use ITargetFrame2 first. otherwise a new browser will open.

	int nRet = 1;
	RH_ITargetFrame2 *pTargetFrame2= NULL;
	s_pstBrowser->QueryInterface(RH_IID_ITargetFrame2, (void**)&pTargetFrame2);
	if (pTargetFrame2 != NULL)
	{
		if (_tcslen(szTargetID) > 0)
		{
			//IE 5.0+
			IUnknown *pUnk = NULL;
			pTargetFrame2->FindFrame(bstrTarget,0,&pUnk);
			if (pUnk != NULL)
			{
				IWebBrowser2 *pBrowser2 = NULL;
				pUnk->QueryInterface(IID_IWebBrowser2,(void **)&pBrowser2);
				if (pBrowser2 != NULL && pBrowser2 != s_pstBrowser)
				{
					s_pstBrowser->Quit();
					s_pstBrowser->Release();
					s_pstBrowser = pBrowser2;
				}
				pUnk->Release();
			}
			else
			{
				hr=pTargetFrame2->SetFrameName(bstrTarget);
				if (!SUCCEEDED(hr))
				{
					s_pstBrowser->Quit();
					s_pstBrowser->Release();
					s_pstBrowser=NULL;
					nRet = 0;
				}
			}
		}
		pTargetFrame2->Release();
	}

	if (nRet)
	{

		BSTR bstr;
		if (!bWebAddress)
		{
			_TCHAR szTempFile[MAX_PATH + 1];
			if (PrepareTempHtmlFile(pszUrl,szTempFile, MAX_PATH) <= MAX_PATH)
			{
				unsigned uLen = (unsigned)_tcslen(szTempFile);
				bstr = ::SysAllocStringLen(NULL, uLen+1);
#ifndef	UNICODE
				MultiByteToWideChar(CP_ACP, MB_USEGLYPHCHARS, szTempFile, (int)uLen, bstr, uLen+1);
#else
				_tcscpy_s(bstr, uLen+1, szTempFile);
#endif
			}
		}
		else
		{
			UINT nLenUrl = _tcslen(pszUrl);
			bstr = ::SysAllocStringLen(NULL, nLenUrl+1);
#ifndef	UNICODE
			MultiByteToWideChar(CP_ACP, MB_USEGLYPHCHARS, pszUrl, (int)nLenUrl, bstr, (int)nLenUrl+1);
#else
			_tcscpy_s(bstr, nLenUrl+1, pszUrl);
#endif
		}

		g_bActivateByDlg=ActivateByDialog();

		hr=s_pstBrowser->put_Visible(VARIANT_FALSE);

		AddIeEventListener(s_pstBrowser, &gHiddenIeEvents);
		hr=s_pstBrowser->Navigate(bstr, &vFlags, &vTargetFrameName, &vPostData, &vHeaders); 

		HWND hWnd;
		hr=s_pstBrowser->get_HWND((long*)&hWnd);
		if (SUCCEEDED(hr))
		{
			::SetForegroundWindow(hWnd);
		}
		::SysFreeString(bstr);
	}


	if (pszNewUrl)
		delete[] pszNewUrl;

	::SysFreeString(bstrTarget);
	return nRet;
}

static unsigned	GetTempFile(_TCHAR *a_pszTempUrl, unsigned uLength)
{
	_TCHAR szTempFile[] = _T("robohelp_csh.htm");
	_TCHAR szPath[MAX_PATH + 1];
	GetTempPath(MAX_PATH, szPath);
	if (a_pszTempUrl != NULL && (unsigned)_tcslen(szPath) + (unsigned)_tcslen(szTempFile) + 1 < uLength)
	{
		_tcscpy_s(a_pszTempUrl, uLength, szPath);
		_tcscat_s(a_pszTempUrl, uLength, _T("robohelp_csh.htm"));
	}
	return ((unsigned)_tcslen(szPath) + (unsigned)_tcslen(szTempFile) + 1);

}
static unsigned PrepareTempHtmlFile(const _TCHAR*a_pszUrl, _TCHAR *a_pszTempUrl, unsigned uLength)
{
	unsigned uFileNameLen = GetTempFile(a_pszTempUrl, uLength);
	if (uFileNameLen<= uLength)
	{
		_TCHAR szNewUrl[_MAX_PATH + _MAX_PATH];

		HANDLE  hFile = CreateFile(a_pszTempUrl, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		_TCHAR szTempFileFormat[] = _T("<html>\r\n")
				_T("<head><meta http-equiv=Content-Type content=\"text/html; charset=utf-8\"></head>\r\n")
				_T("<script language=\"Javascript\">\r\n")
				_T("<!--\r\n")
				_T("document.location=\"%s\";\r\n")
				_T("//-->\r\n")
				_T("</script>\r\n")
				_T("</html>");

		if (hFile != INVALID_HANDLE_VALUE)
		{
			if (_tcsstr(a_pszUrl, _T("://")) == NULL)
			{
				// file system
				_TCHAR *pPos = (_TCHAR *)_tcschr(a_pszUrl, '\\');  //vikumar: TBD - const casting should be taken care of, revisit the API PrepareTempHtmlFile()
				while (pPos != NULL)
				{
					pPos[0] = '/';
					pPos = _tcschr(pPos, '\\');
				}
				_tcscpy_s(szNewUrl, _MAX_PATH + _MAX_PATH, _T("file://"));
				_tcscat_s(szNewUrl, _MAX_PATH + _MAX_PATH, a_pszUrl);
				a_pszUrl = szNewUrl;
			}

			unsigned uLen = (unsigned)_tcslen(szTempFileFormat) + (unsigned)_tcslen(a_pszUrl) - 2;
			unsigned long wlen = 0;
			_TCHAR *pszFullBuffer = new _TCHAR[uLen + 1];
			_stprintf_s(pszFullBuffer, uLen + 1, szTempFileFormat, a_pszUrl);

#ifdef _UNICODE
			unsigned long nDataLength = 0;
			LPSTR pszUTF8Buffer = NULL;
			nDataLength = ::WideCharToMultiByte( CP_UTF8, 0, pszFullBuffer, uLen, pszUTF8Buffer, 0, NULL, NULL );
			pszUTF8Buffer = (LPSTR)new BYTE[nDataLength];
			if(pszUTF8Buffer != NULL)
				::WideCharToMultiByte( CP_UTF8, 0, pszFullBuffer, uLen, pszUTF8Buffer, nDataLength, NULL, NULL );

			WriteFile((HANDLE)hFile, pszUTF8Buffer, nDataLength, &wlen, NULL);
			CloseHandle((HANDLE)hFile);
			if(pszUTF8Buffer)
				delete[] (BYTE*)pszUTF8Buffer;
#else
			WriteFile((HANDLE)hFile, pszFullBuffer, _tcslen(pszFullBuffer), &wlen, NULL);
			CloseHandle((HANDLE)hFile);
#endif
			delete[] pszFullBuffer;
		}
	}
	return uFileNameLen;
}

static int ShowHelpTopic_Win32_NonIE(const _TCHAR *a_pszUrl)
{
	//create a temp html file which will redirect it self to desired url
	_TCHAR szFile[MAX_PATH + 1];

	unsigned uFileNameLength = PrepareTempHtmlFile(a_pszUrl, szFile,MAX_PATH);
	if (uFileNameLength <= MAX_PATH)
	{
		//run shell execute to launch default browsre to view it
		if ((int)ShellExecute(NULL, _T("open"), szFile, NULL, NULL, SW_SHOWNORMAL) > 32)
			return 0;
	}
	return 0;
}
#else
/* Show Help topic in non-Win32 platform */
int ShowHelpTopic_NonWin32(const _TCHAR *a_pszUrl)
{
	/*for non-window 32 system, we call the browser directly.
	 because it is impossible to dectect which browser is installed in non-win32 platform. so we have to hardcode the broser name to "netscape".
	 for those, who have different browser, please update the browser name here.
	*/
	return (execl(s_szBrowserName, a_pszUrl, 0) == -1)? -1: 0;
}
#endif

int	 RH_RegisterTopicBrowser(IUnknown *a_pUnknown)
{
	int nRet = 0;
	RH_UnregisterTopicBrowser();

	if (a_pUnknown)
	{
		HRESULT hr = a_pUnknown->QueryInterface(IID_IWebBrowser2, (void**)&s_pRegisteredTopicBrowser);
		if (hr != S_OK)
		{
			s_pRegisteredTopicBrowser = NULL;
		}
		else
		{
			nRet = 1;
		}
	}
	return nRet;
}

	
int	 RH_UnregisterTopicBrowser()
{
	if (s_pRegisteredTopicBrowser)
	{
		s_pRegisteredTopicBrowser->Quit();
		s_pRegisteredTopicBrowser->Release();
		s_pRegisteredTopicBrowser = NULL;
		s_pOleInPlaceActiveObject->Release();
	}

	return 1;
}

int LaunchProcess(const _TCHAR *a_pszAppExePath, _TCHAR *a_pszCommandLine)
{
	STARTUPINFO si = {0};
	si.cb = sizeof(si);
	PROCESS_INFORMATION pi = {0};
	int iRetVal = 1;

	// Start the process. 
	if(::CreateProcess(a_pszAppExePath, a_pszCommandLine, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
		iRetVal = 0;
		// Close process and thread handles. 
		CloseHandle( pi.hProcess );
		CloseHandle( pi.hThread );
	}
	return iRetVal;
}
