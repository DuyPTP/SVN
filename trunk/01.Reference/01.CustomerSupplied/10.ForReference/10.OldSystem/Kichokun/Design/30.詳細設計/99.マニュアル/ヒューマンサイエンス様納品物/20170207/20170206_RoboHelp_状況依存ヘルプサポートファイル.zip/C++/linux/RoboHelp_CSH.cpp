
/***************************************************************************************** 
Context-Sensitive-Help API for WebHelp, FlashHelp, WebHelp/FlashHelp Pro,  Adobe AIR

Copyright � [2009] Adobe Systems Incorporated.  All rights reserved.
  
*******************************************************************************************/

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include "RoboHelp_CSH.h"
#include <sys/wait.h>

static int FileExists( const char  * inPath );
int LaunchProcess(const char *a_pszAppExePath, char * const argv[]);

static int IsWebAddress(const char * pszHelpSource);
static int IsServerBased(const char *a_pszUrlToHelpSet);
static int WH_ShowWebHelp(int hParent, const char * pszHelpURL, const char *pszWnd, unsigned int uCommand, unsigned long dwData);
static int WH_ShowWebHelp_Server(int hParent, const char * pszHelpURL, const char *pszWnd, unsigned int uCommand, unsigned long dwData);
static int ShowWebHelp(const char * pszURL);
static void onExitForWH(int nExit, void *strTemp);

#define PARAM_LEN				40
#define TEMP_HTML_MAX_LENGTH	1500
#define TEMP_MAX_PATH			300




void onExitForWH(int nExit, void *strTemp)
{
	if(strTemp != NULL)
	{
		remove((char *)strTemp);
		free(strTemp);
	}
}

int LaunchPlatformBrowser( const char * inURL )
{
	static char * gstrTmpFile;

	if(gstrTmpFile == NULL)
	{
		gstrTmpFile = tempnam(NULL , NULL);
		on_exit(onExitForWH , gstrTmpFile );
	}

	if(gstrTmpFile == NULL)
		return 1;

	FILE *fp = fopen(gstrTmpFile , "w");
	if(fp == NULL)
		return 1;

	fprintf(fp, "<html><script language=\"javascript\"><!--\n\twindow.location=\"%s\";\n--></script><body></body></html>", inURL);

	fclose(fp);
	pid_t pid = fork();
	if(pid == 0)
	{
		execlp("firefox" , "firefox" , "-new-window", gstrTmpFile  , (char *)NULL);
		exit(0);
	}
	return 0;
}


int RH_ShowHelpForContext(const char * a_pszHelpFile, 
						 const char *a_pszContext,
						 unsigned int uCommand, 
						 DWORD dwData
						)
{
	if(!a_pszHelpFile)
		return 0;
	unsigned uLen = (unsigned)strlen(a_pszHelpFile);
	if (uLen)
	{
		std::string sHelpSrc = a_pszHelpFile;
		if(a_pszContext && strlen(a_pszContext) > 0)
		{
			char *pszHelp = new char[uLen + 1];
			strcpy(pszHelp, a_pszHelpFile);
			char *pWnd = strchr(pszHelp,'>');
			if (pWnd)
			{
				*pWnd='\0';
				pWnd++;
			}

			char slashCh = '/';
			char *pMainPage = strchr(pszHelp, '/');
			if(!pMainPage)
			{
				pMainPage = strchr(pszHelp, '\\');
				slashCh = '\\';
			}

			*(pMainPage+1) = '\0';
			sHelpSrc = pszHelp;
			sHelpSrc += a_pszContext;
			sHelpSrc += slashCh;
			sHelpSrc += a_pszContext;
			sHelpSrc += _T(".htm");
			if(pWnd && strlen(pWnd) > 0)
			{
				sHelpSrc += '>';
				sHelpSrc += pWnd;
			}
			delete []pszHelp;
		}
		return RH_ShowHelp(-1, sHelpSrc.c_str(), uCommand, dwData);
}

int RH_ShowHelp(int hParent, const char * a_pszHelpFile, unsigned int uCommand, unsigned long dwData)
{
	int nRet = 0;

	if (FileExists( a_pszHelpFile))
	{
		unsigned int uLen = (unsigned)strlen(a_pszHelpFile);
		if (uLen)
		{
			char *pszHelp = new char[uLen + 1];
			strcpy(pszHelp, a_pszHelpFile);
			char *pWnd = strchr(pszHelp,'>');
			if (pWnd)
			{
				*pWnd='\0';
				pWnd++;
			}

			if (IsServerBased(pszHelp))
			{
				nRet = WH_ShowWebHelp_Server(hParent, pszHelp, pWnd, uCommand, dwData);
			}

			else
			{
				nRet = WH_ShowWebHelp(hParent, pszHelp, pWnd, uCommand, dwData);
			}
			delete []pszHelp;
		}
	}
	return nRet;
}

int WH_ShowWebHelp(int hParent, const char * pszHelpURL, const char *pszWnd, unsigned int uCommand, unsigned long dwData)
{
	int nRet = 0;
	char szParam[PARAM_LEN];
	switch (uCommand)
	{
	case HH_DISPLAY_TOPIC:
		{
			strcpy(szParam, ("#<id=0"));
		}
		break;
	case HH_HELP_CONTEXT:
		{
			int nId = dwData;
			// Fixed Bug#
			if(nId == 0) return 1;
			sprintf(szParam, ("#<id=%d"), nId);
		}
		break;
	case HH_DISPLAY_INDEX:
		{
			strcpy(szParam, ("#<cmd=idx"));
		}
		break;
	case HH_DISPLAY_SEARCH:
		{
			strcpy(szParam, ("#<cmd=fts"));
		}
		break;
	case HH_DISPLAY_TOC:
		{
			strcpy(szParam,  ("#<cmd=toc"));
		}
		break;
	}
	if (strlen(szParam)!=0)
	{
		unsigned uWndLength = 0;
		if (pszWnd)
			uWndLength = (unsigned)strlen(pszWnd) + 6;

		char *pszURL=new char[strlen(pszHelpURL) + strlen(szParam) + uWndLength + PARAM_LEN];
		strcpy(pszURL, pszHelpURL);
		strcat(pszURL, szParam);
		if (pszWnd)
		{

			strcat(pszURL, (">>wnd="));
			strcat(pszURL, pszWnd);
		}
		strcat(pszURL,">>newwnd=false");
		nRet = ShowWebHelp(pszURL);
		delete[] pszURL;
	}
	return nRet;
}

int WH_ShowWebHelp_Server(int hParent, const char * pszHelpURL, const char *pszWnd, unsigned int uCommand, unsigned long dwData)
{
	int nRet=0;
	char szParam[PARAM_LEN];
	int nCmd=0;
	switch (uCommand)
	{
	case HH_HELP_CONTEXT:
		{
			int nId = dwData;
			const char *pPos = strchr(pszHelpURL, ('?'));
			if (pPos != NULL)
				sprintf(szParam, "&ctxid=%d", nId);
			else
				sprintf(szParam, "?ctxid=%d" , nId);
			nCmd = 1;
		}
		break;
	case HH_DISPLAY_INDEX:
	case HH_DISPLAY_SEARCH:
	case HH_DISPLAY_TOPIC:
	case HH_DISPLAY_TOC:
		{
			const char *pPos = strchr(pszHelpURL, ('?'));
			if (pPos != NULL)
				strcpy(szParam, ("&ctxid=0"));
			else
				strcpy(szParam, ("?ctxid=0"));
            nCmd = 1;
		}
		break;
	}
	if (nCmd)
	{
		unsigned uWndLength = 0;
		if (pszWnd)
			uWndLength = (unsigned)strlen(pszWnd) + 1;

		char *pszURL=new char[strlen(pszHelpURL) + strlen(szParam) + uWndLength + 1];
		strcpy(pszURL, pszHelpURL);
		strcat(pszURL, szParam);
		if (pszWnd)
		{
			strcat(pszURL, (">"));
			strcat(pszURL, pszWnd);
		}
		nRet = ShowWebHelp( pszURL);
		delete[] pszURL;
	}
	return nRet;
}

int ShowWebHelp(const char *pszURL)
{
	return LaunchPlatformBrowser(pszURL);
}

int IsServerBased(const char *a_pszUrlToHelpSet)
{
	int nRet = 1;
	if (strlen(a_pszUrlToHelpSet) > 0)
	{
		const char *pDot = strchr(a_pszUrlToHelpSet,'.');
		if ((pDot != 0) &&
			((a_pszUrlToHelpSet + strlen(a_pszUrlToHelpSet) - pDot) >= 4) &&
			(strncasecmp (pDot,(".htm"), 4) == 0))
		{
			nRet = 0;
		}
	}
	return nRet;
}


int RH_AIR_ShowHelp(const char * a_pszViewerPath,
					const char * a_pszHelpId,
					const char * a_pszWindowName,
					unsigned long ulMapNum,
					const char * a_pszMapId,
					const char * a_pszTopicURL)
{
	int iRetVal = 1;

	if(FileExists(a_pszViewerPath))
	{
		char * argv[20];
		int ndx = 0 ;

		char szTemp[25];
		argv[ndx ++ ] = (char *)a_pszViewerPath;
		argv[ndx++] = "-csh" ;


	   	if(a_pszHelpId != NULL && strlen((const char *)a_pszHelpId ) > 0)
		{
			argv[ndx ++] = "helpid" ;
			argv[ndx ++] =  (char *)a_pszHelpId ;
		}

		if(a_pszWindowName!=NULL && strlen((const char *)a_pszWindowName)>0)
		{
			argv[ndx ++] = "window" ;
			argv[ndx ++] =  (char *)a_pszWindowName;
		}

		if(a_pszTopicURL && strlen((const char *)a_pszTopicURL))
		{
			argv[ndx ++] = "topicurl" ;
			argv[ndx ++] =  (char *)a_pszTopicURL;
		}
		else if(a_pszMapId && strlen((const char *) a_pszMapId))
		{
			argv[ndx ++] = "mapid" ;
			argv[ndx ++] = (char *)a_pszMapId;
		}
		else
		{
			argv[ndx ++] = "mapnumber" ;
			sprintf(szTemp,"%d", ulMapNum);
			argv[ndx ++] =  szTemp;

		}
		argv[ndx] = (char *)NULL;
		iRetVal = LaunchProcess(a_pszViewerPath, argv);
	}
	return iRetVal;
}

int RH_Show_BrowserBasedHelp(HWND hParent, 
							 const char * pszHelpURL,
							 const char *pszContext,
							 const char *pszWnd,
							 unsigned int uCommand,
							 DWORD dwData
							 )
 {
	int nRet = 0;
	char szParam[PARAM_LEN];
	switch (uCommand)
	{
	case HH_DISPLAY_TOPIC:
		{
			strcpy(szParam, ("#<id=0"));
		}
		break;
	case HH_HELP_CONTEXT:
		{
			int nId = dwData;
			// Fixed Bug# 
			if(nId == 0) return 1;
			sprintf(szParam, ("#<id=%d"), nId);
		}
		break;
	case HH_DISPLAY_INDEX:
		{
			strcpy(szParam, ("#<cmd=idx"));
		}
		break;
	case HH_DISPLAY_SEARCH:
		{
			strcpy(szParam, ("#<cmd=fts"));
		}
		break;
	case HH_DISPLAY_TOC:
		{
			strcpy(szParam,  ("#<cmd=toc"));
		}
		break;
	}
	if (strlen(szParam)!=0)
	{
		char *pszURL=new char[strlen(pszHelpURL) + strlen(szParam) + PARAM_LEN];
		strcpy(pszURL, pszHelpURL);
		strcat(pszURL, szParam);
		if (pszWnd)
		{
			strcat(pszURL, (">>wnd="));
			strcat(pszURL, pszWnd);
		}
		if (pszContext)
		{
			strcat(pszURL, (">>helpid="));
			strcat(pszURL, pszContext);
		}
		strcat(pszURL,">>newwnd=false");
		nRet = ShowWebHelp(pszURL);
		delete[] pszURL;
	}
	return nRet;
 }

int FileExists( const char  * inPath )
{
	FILE * fp = fopen(inPath , "r") ;
	int nRet = 0;
	if(fp)
	{
		nRet = 1;
		fclose(fp);
	}
	return nRet;
}

int LaunchProcess(const char *a_pszAppExePath, char * const argv[])
{
	int i = 0;
	if(fork() == 0)
	{
		execv(a_pszAppExePath , argv);
		_exit(0);
	}
	return 1;
}




