/***************************************************************************************** 
Context-Sensitive-Help API for WebHelp, FlashHelp  WebHelp/FlashHelp Pro  Adobe AIR

Copyright � [2009] Adobe Systems Incorporated. All rights reserved.
  
*******************************************************************************************/
#ifndef _ROBOHELP_CSH_H
#define _ROBOHELP_CSH_H

// General Constants
#define HH_DISPLAY_TOPIC  0
#define HH_DISPLAY_TOC  1
#define HH_DISPLAY_INDEX  2
#define HH_DISPLAY_SEARCH  3
#define HH_HELP_CONTEXT  15

//   RH_ShowHelp
//		[in] hwndParent	-  this argument is not used in the case of linux
//		[in] a_pszHelpFile	-  Path to help system start page ("http://www.myurl.com/help/help.htm" or "/help/help.htm")
//				      For custom windows (defined in Help project), add ">" followed by the window name ("/help/help.htm>mywin") 
//
//		[in] uCommand		-  Command to display help. One of the following:
//				               HH_HELP_CONTEXT     ' Displays the topic associated with the Map ID sent in dwData
//				               						if 0, then default topic is displayed.
//				               
//				               The following display the default topic and the Search, Index, or TOC pane.
//          					Note: The pane displayed in WebHelp Pro will always be the window's default pane.
//
//                    				HH_DISPLAY_SEARCH
//		                   			HH_DISPLAY_INDEX
//      	              			HH_DISPLAY_TOC
//		[in] dwData			- 	Map ID associated with the topic to open (if using HH_HELP_CONTEXT), otherwise 0
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_ShowHelp(int hParent,
				const char * a_pszHelpFile,
				unsigned int uCommand,
				unsigned long dwData);


//This API works for only Webhelp output with Multiple Table of contents.
//RH_ShowHelpForContext
//		[in] hwndParent		- window handle to the parent window.
//		[in] a_pszHelpFile	- help file name or url to server-based help system
//		[in] a_pszContext   - Context or role name
//		[in] uCommand		- pre-defined command used based on the help file
//		[in] dwData			- extra data based on the uCommand parameter specified
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_ShowHelpForContext(const char * a_pszHelpFile, 
						 const char *a_pszContext,
						 unsigned int uCommand, 
						 DWORD dwData
						);

//   RH_AIR_ShowHelp
//		[in] a_pszViewerPath	- Path to the installation directory of AIR Help Application.
//		[in] a_pszHelpId		- [optional] id of help content to be viewed in Viewer. It is specified in .helpcfg file.
//		[in] a_pszWindowName	- [optional] customized named output window
//		[in] ulMapNum			- Content Sensitive Map Number. 
//		[in] a_pszMapId			- [optional] String representation of ulMapNum. If specified this takes priority and ulMapNum is ignored.
//		[in] a_pszTopicURL		- [optional] URL of topic to be shown. If specified this takes priority over ulMapNum and a_pszMapId.
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_AIR_ShowHelp(const char * a_pszViewerPath,
				const char  * a_pszHelpId,
				const char * a_pszWindowName,
				unsigned long ulMapNum,
				const char  * a_pszMapId,
				const char * a_pszTopicURL);

//   RH_Show_BrowserBasedHelp
//		[in] hwndParent			- window handle to the parent window.
//		[in] pszHelpURL			- help file name or url to server-based help system
//		[in] pszContext			- Context or role name
//		[in] a_pszWindowName	- [optional] customized named output window
//		[in] uCommand			- pre-defined command used based on the help file
//		[in] dwData				- extra data based on the uCommand parameter specified
//		The return value is	0 for a successful result and non-zero if an error occurs.
int RH_Show_BrowserBasedHelp(HWND hParent, 
							 const char * pszHelpURL,
							 const char *pszContext,
							 const char *pszWnd,
							 unsigned int uCommand,
							 DWORD dwData
							 );


#endif
